/**
 * Rudnexx Visitor Analytics
 * Pings the SaaS API to count unique visitors while preventing double-counts on refresh.
 */
(function () {
    // Check if we've already counted this session's visit to this page
    const pagePath = window.location.pathname;
    const sessionKey = 'rnx_visted_' + btoa(pagePath).substring(0, 16);

    if (sessionStorage.getItem(sessionKey)) {
        return; // Prevent counting on refresh within the same session
    }

    // Ping the SaaS API (using the constant defined in PHP)
    const apiUrl = rudnexx_vars.api_url + '/analytics/visit';

    fetch(apiUrl, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({
            path: pagePath,
            license: rudnexx_vars.license_key
        }),
        // Use keepalive so the request completes even if the user navigates away quickly
        keepalive: true
    }).then(() => {
        sessionStorage.setItem(sessionKey, '1');
    }).catch(err => {
        // Silent fail for analytics
    });
})();
