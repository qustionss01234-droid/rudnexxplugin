<?php
if (!defined('ABSPATH')) {
    exit;
}

// Register custom 5-minute cron schedule for testing
add_filter('cron_schedules', 'rudnexx_add_cron_intervals');
function rudnexx_add_cron_intervals($schedules) {
    if (!isset($schedules['rudnexx_every5min'])) {
        $schedules['rudnexx_every5min'] = [
            'interval' => 300, // 5 minutes in seconds
            'display'  => __('Every 5 Minutes (Testing)'),
        ];
    }
    return $schedules;
}

// Hook into WP Cron
add_action('rudnexx_auto_blog_cron', 'rudnexx_cron_execute');

function rudnexx_cron_execute() {
    // 1. Verify License with our Next.js API First
    $license_key = get_option('rudnexx_license_key');
    if (empty($license_key)) return;

    // Call Next.js Server
    $verification = wp_remote_post(RUDNEXX_API_URL . '/license/verify', [
        'body' => json_encode([
            'licenseKey' => $license_key,
            'domain' => $_SERVER['SERVER_NAME']
        ]),
        'headers' => ['Content-Type' => 'application/json']
    ]);

    if (is_wp_error($verification)) return;
    $response = json_decode(wp_remote_retrieve_body($verification), true);

    if (!isset($response['status']) || $response['status'] !== 'valid') {
        update_option('rudnexx_license_status', 'Revoked/Expired');
        return; // Halt if nulled/pirated/expired
    }

    update_option('rudnexx_license_status', 'Active');

    // 2. Fetch Topic from Bulk Queue
    $bulk_keywords = get_option('rudnexx_bulk_keywords', '');
    $keywords_array = array_filter(array_map('trim', explode("\n", $bulk_keywords)));

    if (empty($keywords_array)) {
        return; // No keywords left in the queue
    }

    // Get the first keyword
    $topic = array_shift($keywords_array);

    // 3. Generate Content
    $post_data = rudnexx_generate_post($topic);

    // 4. Publish to WordPress
    if ($post_data && !empty($post_data['title']) && !empty($post_data['content'])) {
        $new_post = [
            'post_title'    => wp_strip_all_tags($post_data['title']),
            'post_content'  => wp_kses_post($post_data['content']),
            'post_status'   => 'publish',
            'post_author'   => 1,
            'post_name'     => isset($post_data['slug']) ? sanitize_title($post_data['slug']) : ''
        ];

        // Insert the post
        $post_id = wp_insert_post($new_post);

        if ($post_id && !is_wp_error($post_id)) {
            // Track AI Generation for Analytics
            update_post_meta($post_id, 'rudnexx_generated', 1);
            update_post_meta($post_id, 'rudnexx_ai_provider', get_option('rudnexx_active_provider', 'unknown'));

            // Add Tags
            if (!empty($post_data['tags']) && is_array($post_data['tags'])) {
                wp_set_post_tags($post_id, $post_data['tags']);
            }

            // Set SEO Metadata for popular plugins (Yoast & RankMath)
            if (!empty($post_data['seo_title'])) {
                update_post_meta($post_id, '_yoast_wpseo_title', sanitize_text_field($post_data['seo_title']));
                update_post_meta($post_id, 'rank_math_title', sanitize_text_field($post_data['seo_title']));
            }
            if (!empty($post_data['meta_description'])) {
                update_post_meta($post_id, '_yoast_wpseo_metadesc', sanitize_textarea_field($post_data['meta_description']));
                update_post_meta($post_id, 'rank_math_description', sanitize_textarea_field($post_data['meta_description']));
            }

            // SEO Score Badge — shown in Posts list (Save this BEFORE image fetch to prevent timeout loss)
            if (isset($post_data['seo_score'])) {
                update_post_meta($post_id, 'rudnexx_seo_score', intval($post_data['seo_score']));
            }

            // Featured Image Automation (External API call, prone to timeout)
            if (!empty($post_data['image_keyword'])) {
                rudnexx_sideload_featured_image($post_id, $post_data['image_keyword']);
            }

            // Remove the processed keyword from the queue
            $updated_queue = implode("\n", $keywords_array);
            update_option('rudnexx_bulk_keywords', $updated_queue);
        } else {
            error_log("Rudnexx: Failed to insert post. " . (is_wp_error($post_id) ? $post_id->get_error_message() : ''));
        }
    }
}

/**
 * Downloads an image from Unsplash and sets it as the Featured Image
 */
function rudnexx_sideload_featured_image($post_id, $keyword) {
    require_once(ABSPATH . 'wp-admin/includes/media.php');
    require_once(ABSPATH . 'wp-admin/includes/file.php');
    require_once(ABSPATH . 'wp-admin/includes/image.php');

    $search_term = urlencode(sanitize_text_field($keyword));
    // Using Unsplash Source API for random relevant image (1200x800 for good blog headers)
    $image_url = "https://source.unsplash.com/1200x800/?" . $search_term;

    $temp_file = download_url($image_url);

    if (is_wp_error($temp_file)) {
        error_log("Rudnexx Image Download Error: " . $temp_file->get_error_message());
        return false;
    }

    $file = [
        'name'     => $search_term . '-' . rand(100, 999) . '.jpg',
        'type'     => 'image/jpeg',
        'tmp_name' => $temp_file,
        'error'    => 0,
        'size'     => filesize($temp_file),
    ];

    $attachment_id = media_handle_sideload($file, $post_id);

    if (is_wp_error($attachment_id)) {
        @unlink($file['tmp_name']);
        error_log("Rudnexx Image Attach Error: " . $attachment_id->get_error_message());
        return false;
    }

    // Set the image as the post thumbnail
    set_post_thumbnail($post_id, $attachment_id);
    return true;
}
