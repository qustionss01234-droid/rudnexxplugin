<?php
if (!defined('ABSPATH')) { exit; }

add_action('admin_menu', 'rudnexx_admin_menu');
function rudnexx_admin_menu() {
    add_menu_page('Rudnexx Settings', 'Rudnexx AI', 'manage_options', 'rudnexx-settings', 'rudnexx_settings_page_html', RUDNEXX_PLUGIN_URL . 'assets/logo.png', 25);
}

add_action('admin_init', 'rudnexx_register_settings');
function rudnexx_register_settings() {
    require_once plugin_dir_path(__FILE__) . 'providers-config.php';
    $provider_config = rudnexx_get_providers();

    // Core settings - these MUST always be registered (registered first to avoid max_input_vars drop)
    $core_settings = [
        'rudnexx_license_key', 'rudnexx_active_provider', 'rudnexx_schedule_frequency',
        'rudnexx_image_source', 'rudnexx_pixabay_key',
        'rudnexx_image_gen_key', 'rudnexx_image_gen_provider', 'rudnexx_rag_source',
        'rudnexx_serper_key'
    ];
    foreach ($core_settings as $opt) {
        if ($opt === 'rudnexx_license_key') {
            register_setting('rudnexx_settings_group', $opt, [
                'sanitize_callback' => function($new_key) {
                    if (strpos($new_key, '••••') !== false) {
                        return get_option('rudnexx_license_key'); // Keep existing if masked
                    }
                    return sanitize_text_field($new_key);
                }
            ]);
        } else {
            register_setting('rudnexx_settings_group', $opt, ['sanitize_callback' => 'sanitize_text_field']);
        }
    }

    // YouTube embed with a strict allowlist sanitizer to ensure it always saves
    register_setting('rudnexx_settings_group', 'rudnexx_youtube_embed', [
        'sanitize_callback' => function($val) {
            return ($val === 'enabled') ? 'enabled' : 'disabled';
        },
        'default' => 'disabled',
    ]);

    // Content Strategy Arrays
    register_setting('rudnexx_settings_group', 'rudnexx_selected_products', [
        'sanitize_callback' => function($val) { return is_array($val) ? array_map('intval', $val) : []; },
        'default' => []
    ]);
    register_setting('rudnexx_settings_group', 'rudnexx_selected_pages', [
        'sanitize_callback' => function($val) { return is_array($val) ? array_map('intval', $val) : []; },
        'default' => []
    ]);

    // Provider-specific settings (registered last — may be dropped if too many, but core settings above are protected)
    foreach ($provider_config as $val => $cfg) {
        register_setting('rudnexx_settings_group', 'rudnexx_' . $val . '_key',   ['sanitize_callback' => 'sanitize_text_field']);
        register_setting('rudnexx_settings_group', 'rudnexx_' . $val . '_model', ['sanitize_callback' => 'sanitize_text_field']);
    }
}

// Automatically reset WP-Cron schedule whenever settings are saved
add_action('update_option_rudnexx_schedule_frequency', 'rudnexx_reschedule_cron_handler', 10, 2);
function rudnexx_reschedule_cron_handler($old_value, $new_value) {
    // This catches when the dropdown value actually changes
    rudnexx_force_reschedule_cron($new_value);
}

// Catch when settings are saved but the value didn't change (e.g. to fix a broken cron)
add_action('admin_init', function() {
    if (isset($_GET['settings-updated']) && $_GET['settings-updated']) {
        rudnexx_force_reschedule_cron(get_option('rudnexx_schedule_frequency', 'hourly'));
    }
});

function rudnexx_force_reschedule_cron($frequency) {
    if (!$frequency) return;
    $timestamp = wp_next_scheduled('rudnexx_auto_blog_cron');
    if ($timestamp) {
        wp_unschedule_event($timestamp, 'rudnexx_auto_blog_cron');
    }
    
    // Get the interval in seconds to delay the very first run (so it doesn't run instantly upon save)
    $schedules = wp_get_schedules();
    $delay = isset($schedules[$frequency]['interval']) ? $schedules[$frequency]['interval'] : 3600;
    
    wp_schedule_event(time() + $delay, $frequency, 'rudnexx_auto_blog_cron');
}

// Handle Flush Permalinks (Sync Fix)
add_action('admin_post_rudnexx_fix_sync', 'rudnexx_handle_fix_sync');
function rudnexx_handle_fix_sync() {
    if (!current_user_can('manage_options') || !check_admin_referer('rudnexx_fix_sync')) {
        wp_die('Unauthorized');
    }
    flush_rewrite_rules();
    wp_redirect(add_query_arg(['page' => 'rudnexx-settings', 'rnx_msg' => 'sync_fixed'], admin_url('admin.php')));
    exit;
}


// Handle manual Queue save
add_action('admin_post_rudnexx_save_queue', 'rudnexx_handle_save_queue');
function rudnexx_handle_save_queue() {
    if (!current_user_can('manage_options') || !check_admin_referer('rudnexx_save_queue')) {
        wp_die('Unauthorized');
    }
    $raw = isset($_POST['rudnexx_bulk_keywords']) ? wp_unslash($_POST['rudnexx_bulk_keywords']) : '';
    $lines = array_filter(array_map('trim', explode("\n", $raw)));
    update_option('rudnexx_bulk_keywords', implode("\n", $lines));
    wp_redirect(add_query_arg(['page' => 'rudnexx-settings', 'rnx_msg' => 'queue_saved'], admin_url('admin.php')));
    exit;
}

// Handle Bulk CSV Upload
add_action('admin_post_rudnexx_upload_csv', 'rudnexx_handle_csv_upload');
function rudnexx_handle_csv_upload() {
    if (!current_user_can('manage_options') || !check_admin_referer('rudnexx_upload_csv')) {
        wp_die('Unauthorized');
    }

    if (empty($_FILES['csv_file']['tmp_name'])) {
        wp_redirect(add_query_arg(['page' => 'rudnexx-settings', 'rnx_msg' => 'csv_empty'], admin_url('admin.php')));
        exit;
    }

    $file = fopen($_FILES['csv_file']['tmp_name'], 'r');
    $new_keywords = [];

    while (($row = fgetcsv($file)) !== false) {
        if (!empty($row[0])) {
            $cleaned = sanitize_text_field(trim($row[0]));
            if ($cleaned) $new_keywords[] = $cleaned;
        }
    }
    fclose($file);

    if (empty($new_keywords)) {
        wp_redirect(add_query_arg(['page' => 'rudnexx-settings', 'rnx_msg' => 'csv_no_data'], admin_url('admin.php')));
        exit;
    }

    $existing_raw = get_option('rudnexx_bulk_keywords', '');
    $existing = array_filter(array_map('trim', explode("\n", $existing_raw)));
    
    // Merge and remove duplicates
    $merged = array_unique(array_merge($existing, $new_keywords));
    
    update_option('rudnexx_bulk_keywords', implode("\n", $merged));

    wp_redirect(add_query_arg(['page' => 'rudnexx-settings', 'rnx_msg' => 'csv_success', 'csv_count' => count($new_keywords)], admin_url('admin.php')));
    exit;
}

// Handle manual post generation triggered from the settings page
add_action('admin_post_rudnexx_generate_now', 'rudnexx_handle_generate_now');
function rudnexx_handle_generate_now() {
    if (!current_user_can('manage_options') || !check_admin_referer('rudnexx_generate_now')) {
        wp_die('Unauthorized');
    }

    $keyword = sanitize_text_field($_POST['rudnexx_test_keyword'] ?? '');
    if (empty($keyword)) {
        wp_redirect(add_query_arg(['page' => 'rudnexx-settings', 'rnx_msg' => 'empty'], admin_url('admin.php')));
        exit;
    }

    $post_data = rudnexx_generate_post($keyword);

    if (is_wp_error($post_data)) {
        wp_redirect(add_query_arg([
            'page' => 'rudnexx-settings', 
            'rnx_msg' => 'fail', 
            'rnx_err' => urlencode($post_data->get_error_message())
        ], admin_url('admin.php')));
        exit;
    }

    if ($post_data && !empty($post_data['title']) && !empty($post_data['content'])) {
        $new_post = [
            'post_title'   => wp_strip_all_tags($post_data['title']),
            'post_content' => wp_kses_post($post_data['content']),
            'post_status'  => 'publish',
            'post_author'  => get_current_user_id(),
            'post_name'    => isset($post_data['slug']) ? sanitize_title($post_data['slug']) : '',
        ];
        $post_id = wp_insert_post($new_post);

        if ($post_id && !is_wp_error($post_id)) {
            // Track AI Generation for Analytics
            update_post_meta($post_id, 'rudnexx_generated', 1);
            update_post_meta($post_id, 'rudnexx_ai_provider', get_option('rudnexx_active_provider', 'unknown'));

            if (!empty($post_data['tags']) && is_array($post_data['tags'])) wp_set_post_tags($post_id, $post_data['tags']);
            if (!empty($post_data['seo_title']))      { update_post_meta($post_id, '_yoast_wpseo_title', $post_data['seo_title']); update_post_meta($post_id, 'rank_math_title', $post_data['seo_title']); }
            if (!empty($post_data['meta_description'])) { update_post_meta($post_id, '_yoast_wpseo_metadesc', $post_data['meta_description']); update_post_meta($post_id, 'rank_math_description', $post_data['meta_description']); }
            
            if (isset($post_data['seo_score'])) {
                update_post_meta($post_id, 'rudnexx_seo_score', intval($post_data['seo_score']));
            }

            // Featured Image - Hybrid handler
            rudnexx_set_featured_image($post_id, $post_data);

            wp_redirect(add_query_arg(['page' => 'rudnexx-settings', 'rnx_msg' => 'success', 'rnx_post' => $post_id], admin_url('admin.php')));
            exit;
        }
    }

    wp_redirect(add_query_arg(['page' => 'rudnexx-settings', 'rnx_msg' => 'fail'], admin_url('admin.php')));
    exit;
}

// Handle force execution of the Autopilot Queue
add_action('admin_post_rudnexx_force_cron', 'rudnexx_handle_force_cron');
function rudnexx_handle_force_cron() {
    if (!current_user_can('manage_options') || !check_admin_referer('rudnexx_force_cron')) {
        wp_die('Unauthorized');
    }

    // Call the actual scheduler logic instead of waiting for the cron
    require_once dirname(__FILE__) . '/scheduler.php';
    if (function_exists('rudnexx_cron_execute')) {
        rudnexx_cron_execute();
    }

    wp_redirect(add_query_arg(['page' => 'rudnexx-settings', 'rnx_msg' => 'cron_forced'], admin_url('admin.php')));
    exit;
}

function rudnexx_settings_page_html() {
    if (!current_user_can('manage_options')) return;

    $license_key  = get_option('rudnexx_license_key', '');
    $status       = get_option('rudnexx_license_status', 'Inactive');
    $current_plan = get_option('rudnexx_license_plan', 'free');
    $provider     = get_option('rudnexx_active_provider', 'openai');
    $active_model = get_option('rudnexx_active_model', '');

    require_once plugin_dir_path(__FILE__) . 'providers-config.php';
    $provider_config = rudnexx_get_providers();
    ?>
    <style>
        .rnx-wrap{max-width:860px;margin:20px auto;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif}
        .rnx-card{background:#fff;border:1px solid #e0e0e0;border-radius:10px;padding:24px 28px;margin-bottom:20px;box-shadow:0 1px 4px rgba(0,0,0,.06)}
        .rnx-card h2{margin:0 0 20px;font-size:15px;font-weight:600;color:#1a1a2e;border-bottom:2px solid #f0f0f0;padding-bottom:12px}
        .rnx-badge{display:inline-block;padding:3px 10px;border-radius:20px;font-size:12px;font-weight:600}
        .rnx-badge.active{background:#d4edda;color:#155724}
        .rnx-badge.invalid{background:#f8d7da;color:#721c24}
        .rnx-badge.inactive{background:#fff3cd;color:#856404}
        .rnx-field{margin-bottom:16px}
        .rnx-field label{display:block;font-size:13px;font-weight:600;color:#555;margin-bottom:6px}
        .rnx-field input,.rnx-field select,.rnx-field textarea{width:100%;padding:9px 12px;border:1px solid #d0d0d0;border-radius:6px;font-size:14px;box-sizing:border-box;transition:border .2s}
        .rnx-field input:focus,.rnx-field select:focus,.rnx-field textarea:focus{border-color:#6c63ff;outline:none;box-shadow:0 0 0 3px rgba(108,99,255,.15)}
        .rnx-hint{font-size:12px;color:#888;margin-top:4px}
        .rnx-btn{display:inline-block;padding:9px 22px;background:#6c63ff;color:#fff;border:none;border-radius:6px;font-size:14px;font-weight:600;cursor:pointer}
        .rnx-btn:hover{background:#5a52d5;color:#fff}
        .rnx-btn-sm{font-size:12px;padding:4px 14px;text-decoration:none;border:2px solid #6c63ff;color:#6c63ff;border-radius:6px;display:inline-block}
        .rnx-btn-sm:hover{background:#6c63ff;color:#fff}
        .rnx-provider-block{display:none}
        .rnx-hub-card{background:linear-gradient(135deg,#f8fafc,#fff);border:1px solid #e2e8f0;border-radius:12px;padding:16px;display:flex;align-items:center;gap:12px;transition:all 0.3s ease}
        .rnx-hub-card:hover{transform:translateY(-2px);box-shadow:0 10px 20px rgba(0,0,0,0.05);border-color:#6366f1}
        .rnx-hub-icon{width:40px;height:40px;background:#6366f1;color:#fff;border-radius:10px;display:flex;align-items:center;justify-content:center;flex-shrink:0}
        .rnx-hub-status{font-size:10px;font-weight:700;text-transform:uppercase;padding:2px 8px;border-radius:10px;margin-left:auto}
        .rnx-status-ok{background:#dcfce7;color:#15803d}
    </style>

    <div class="rnx-wrap">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:24px">
            <div style="display:flex;align-items:center;gap:12px">
                <span class="dashicons dashicons-robot" style="font-size:30px;color:#6c63ff"></span>
                <div>
                    <h1 style="margin:0;font-size:22px;color:#1a1a2e">Rudnexx AI Auto-Blogger</h1>
                    <p style="margin:0;color:#888;font-size:13px">Configure your license, AI provider, and automation settings.</p>
                </div>
            </div>
            <div style="text-align:right">
                <span style="background:#e0e7ff;color:#4338ca;padding:4px 12px;border-radius:12px;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:1px">Phase 2: Autopilot Active</span>
            </div>
        </div>

        <?php settings_errors('rudnexx_messages'); ?>

        <div style="display:grid;grid-template-columns: 1fr 280px;gap:20px;">
            <div class="rnx-main">
                <!-- MASTER SETTINGS FORM -->
                <form method="post" action="options.php">
                    <?php settings_fields('rudnexx_settings_group'); ?>

                    <!-- LICENSE -->
                    <div class="rnx-card">
                        <h2>🔑 License Key</h2>
                        <div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:16px">
                            <span>Status:</span>
                            <span class="rnx-badge <?php echo esc_attr(strtolower($status)); ?>"><?php echo esc_html($status); ?></span>
                            <?php if (!empty($current_plan)): ?>
                                <span class="rnx-badge" style="background:#e8f0fe;color:#1a73e8"><?php echo esc_html(ucfirst($current_plan)); ?> Plan</span>
                            <?php endif; ?>
                            <?php if ($current_plan !== 'growth' && $current_plan !== 'agency'): ?>
                                <a href="https://rudnex.in" target="_blank" class="rnx-btn-sm">⬆ Upgrade Plan</a>
                            <?php endif; ?>
                        </div>
                        <div class="rnx-field">
                    <label>License Key</label>
                    <?php 
                    $display_key = '';
                    if (!empty($license_key)) {
                        $prefix = substr($license_key, 0, 7); // rNX_WP_
                        $last_4 = substr($license_key, -4);
                        $display_key = $prefix . str_repeat('•', 8) . $last_4;
                    }
                    ?>
                    <input type="text" name="rudnexx_license_key" 
                           id="rnx_license_field"
                           value="<?php echo esc_attr($display_key); ?>" 
                           onfocus="if(this.value.includes('•')){this.value='';}"
                           placeholder="<?php echo empty($license_key) ? 'rNX_WP_...' : '•••• Enter new key to change ••••'; ?>"
                           style="user-select:none !important;-webkit-user-select:none !important;-moz-user-select:none !important;-ms-user-select:none !important;" />
                    <p class="rnx-hint">For security, your key is masked. Type a new key and save to update it.</p>
                </div>

                <script>
                document.getElementById('rnx_license_field').addEventListener('copy', function(e) {
                    e.preventDefault();
                    alert('Security: Copying the license key is disabled.');
                    return false;
                });
                document.getElementById('rnx_license_field').addEventListener('contextmenu', function(e) {
                    e.preventDefault();
                    alert('Security: Right-click is disabled on sensitive fields.');
                    return false;
                });
                </script>
                    </div>

                    <!-- AUTOMATION & RESEARCH -->
                    <div class="rnx-card">
                        <h2>⚙️ Automation & Research</h2>
                        <div style="display:grid; grid-template-columns: 1fr 1fr; gap:16px;">
                            <div class="rnx-field">
                                <label>Autopilot Frequency</label>
                                <select name="rudnexx_schedule_frequency">
                                    <?php 
                                    $freq = get_option('rudnexx_schedule_frequency', 'hourly');
                                    foreach(['five_minutes'=>'5 Minutes (Turbo)', 'hourly'=>'Hourly', 'twicedaily'=>'Twice Daily', 'daily'=>'Daily', 'weekly'=>'Weekly'] as $v=>$l) {
                                        echo "<option value='$v' ".selected($freq,$v,false).">$l</option>";
                                    } ?>
                                </select>
                            </div>
                            <div class="rnx-field">
                                <label>YouTube Auto-Embed</label>
                                <select name="rudnexx_youtube_embed">
                                    <option value="disabled" <?php selected(get_option('rudnexx_youtube_embed'), 'disabled'); ?>>Disabled</option>
                                    <option value="enabled" <?php selected(get_option('rudnexx_youtube_embed'), 'enabled'); ?>>Enabled</option>
                                </select>
                            </div>
                        </div>
                        <div style="display:grid; grid-template-columns: 1fr 1fr; gap:16px;">
                            <div class="rnx-field">
                                <label>Web Research Source</label>
                                <select name="rudnexx_rag_source">
                                    <option value="none" <?php selected(get_option('rudnexx_rag_source'), 'none'); ?>>None (AI only)</option>
                                    <option value="serper" <?php selected(get_option('rudnexx_rag_source'), 'serper'); ?>>Google (Serper)</option>
                                </select>
                            </div>
                            <div class="rnx-field">
                                <label>Serper API Key</label>
                                <input type="password" name="rudnexx_serper_key" value="<?php echo esc_attr(get_option('rudnexx_serper_key')); ?>" placeholder="serper_..." />
                            </div>
                        </div>
                    </div>

                    <!-- CONTENT STRATEGY -->
                    <div class="rnx-card">
                        <h2>🎯 Content Strategy (WooCommerce & Pages)</h2>
                        <p style="font-size:13px; color:#666; margin-top:0; margin-bottom:15px;">Select exactly which products or pages the AI should focus on. The AI will read their details and write targeted SEO blogs to promote them.</p>
                        <div style="display:grid; grid-template-columns: 1fr 1fr; gap:16px;">
                            <div class="rnx-field">
                                <label>WooCommerce Products</label>
                                <select name="rudnexx_selected_products[]" multiple style="height:150px;">
                                    <?php
                                    $saved_products = get_option('rudnexx_selected_products', []);
                                    if (class_exists('WooCommerce')) {
                                        $products = wc_get_products(['limit' => -1, 'status' => 'publish']);
                                        if (empty($products)) {
                                            echo '<option disabled>No products found</option>';
                                        } else {
                                            foreach ($products as $p) {
                                                $sel = in_array($p->get_id(), $saved_products) ? 'selected' : '';
                                                echo '<option value="' . esc_attr($p->get_id()) . '" ' . $sel . '>' . esc_html($p->get_name()) . '</option>';
                                            }
                                        }
                                    } else {
                                        echo '<option disabled>WooCommerce is not active on this site</option>';
                                    }
                                    ?>
                                </select>
                                <p class="rnx-hint">Hold Ctrl/Cmd to select multiple products.</p>
                            </div>
                            <div class="rnx-field">
                                <label>Business Pages</label>
                                <select name="rudnexx_selected_pages[]" multiple style="height:150px;">
                                    <?php
                                    $saved_pages = get_option('rudnexx_selected_pages', []);
                                    $pages = get_pages();
                                    if (empty($pages)) {
                                        echo '<option disabled>No pages found</option>';
                                    } else {
                                        foreach ($pages as $p) {
                                            $sel = in_array($p->ID, $saved_pages) ? 'selected' : '';
                                            echo '<option value="' . esc_attr($p->ID) . '" ' . $sel . '>' . esc_html($p->post_title) . '</option>';
                                        }
                                    }
                                    ?>
                                </select>
                                <p class="rnx-hint">Select core service or info pages to promote.</p>
                            </div>
                        </div>
                    </div>

                    <!-- AI SETTINGS -->
                    <div class="rnx-card">
                        <h2>🤖 AI Provider &amp; Model</h2>
                        <div class="rnx-field">
                            <label>AI Provider</label>
                            <select name="rudnexx_active_provider" id="rnx-provider">
                                <?php foreach ($provider_config as $val => $cfg): ?>
                                    <option value="<?php echo esc_attr($val); ?>" <?php selected($provider, $val); ?>><?php echo esc_html($cfg['label']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <?php foreach ($provider_config as $val => $cfg): ?>
                        <div class="rnx-provider-block" id="rnx-block-<?php echo esc_attr($val); ?>">
                            <div class="rnx-field">
                                <label><?php echo esc_html($cfg['label']); ?> API Key</label>
                                <input type="password" name="<?php echo esc_attr($cfg['key_option']); ?>"
                                       value="<?php echo esc_attr(get_option($cfg['key_option'])); ?>"
                                       placeholder="<?php echo esc_attr($cfg['key_placeholder']); ?>" />
                                <p class="rnx-hint">Get key: <a href="<?php echo esc_url($cfg['key_link']); ?>" target="_blank"><?php echo esc_attr($cfg['key_link']); ?></a></p>
                            </div>
                            <div class="rnx-field">
                                <label>Model</label>
                                <select name="rudnexx_<?php echo esc_attr($val); ?>_model" class="rnx-model-select">
                                    <?php 
                                    $saved_model = get_option('rudnexx_' . $val . '_model', '');
                                    foreach ($cfg['models'] as $mid => $mlabel): ?>
                                        <option value="<?php echo esc_attr($mid); ?>" <?php selected($saved_model, $mid); ?>>
                                            <?php echo esc_html($mlabel); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>

                    <!-- IMAGE AUTOMATION -->
                    <div class="rnx-card">
                        <h2>🖼️ Featured Image Automation</h2>
                        <div class="rnx-field">
                            <label>Featured Image Source</label>
                            <select name="rudnexx_image_source" id="rnx-image-source">
                                <option value="none" <?php selected(get_option('rudnexx_image_source'), 'none'); ?>>None</option>
                                <option value="pixabay" <?php selected(get_option('rudnexx_image_source'), 'pixabay'); ?>>Pixabay (Stock Photos)</option>
                                <option value="dalle" <?php selected(get_option('rudnexx_image_source'), 'dalle'); ?>>DALL-E 3 (AI Generation)</option>
                                <option value="stability" <?php selected(get_option('rudnexx_image_source'), 'stability'); ?>>Stability AI (Ultra)</option>
                            </select>
                        </div>
                        
                        <div id="rnx-img-block-pixabay" class="rnx-img-block" style="display:none">
                            <div class="rnx-field">
                                <label>Pixabay API Key</label>
                                <input type="password" name="rudnexx_pixabay_key" value="<?php echo esc_attr(get_option('rudnexx_pixabay_key')); ?>" />
                            </div>
                        </div>

                        <div id="rnx-img-block-gen" class="rnx-img-block" style="display:none">
                            <div class="rnx-field">
                                <label>Image Generation API Key (OpenAI / Stability)</label>
                                <input type="password" name="rudnexx_image_gen_key" value="<?php echo esc_attr(get_option('rudnexx_image_gen_key')); ?>" />
                            </div>
                        </div>
                    </div>

                    <!-- SAVE BUTTON -->

                    <div style="margin-bottom: 24px;">
                        <?php submit_button('💾 Save All Configuration', 'primary', 'submit', false, ['class'=>'rnx-btn', 'style'=>'width:100%;font-size:16px;padding:12px']); ?>
                    </div>
                </form>

                <!-- BULK QUEUE MANAGER -->
                <div class="rnx-card" style="border-top: 4px solid #6c63ff;">
                    <h2>📝 Autopilot Batch Queue</h2>
                    <p style="font-size:13px; color:#64748b; margin-bottom:16px;">Add keywords here (one per line). The Autopilot will process these according to your schedule.</p>
                    
                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" style="margin-bottom:20px;">
                        <input type="hidden" name="action" value="rudnexx_save_queue" />
                        <?php wp_nonce_field('rudnexx_save_queue'); ?>
                        <div class="rnx-field">
                            <textarea name="rudnexx_bulk_keywords" rows="8" placeholder="Enter keywords here..."><?php echo esc_textarea(get_option('rudnexx_bulk_keywords', '')); ?></textarea>
                        </div>
                        <button type="submit" class="rnx-btn" style="width:100%">💾 Update Keyword Queue</button>
                    </form>

                    <div style="background:#f1f5f9; padding:15px; border-radius:8px; border:1px dashed #cbd5e1;">
                        <h4 style="margin:0 0 10px; font-size:13px;">📤 Bulk CSV Import</h4>
                        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" enctype="multipart/form-data">
                            <input type="hidden" name="action" value="rudnexx_upload_csv" />
                            <?php wp_nonce_field('rudnexx_upload_csv'); ?>
                            <div style="display:flex; gap:10px;">
                                <input type="file" name="csv_file" accept=".csv" style="flex:1; font-size:12px;" required />
                                <button type="submit" class="rnx-btn-sm" style="background:#6c63ff; color:#fff;">Upload CSV</button>
                            </div>
                            <p class="rnx-hint">CSV Format: Keyword in the first column.</p>
                        </form>
                    </div>
                </div>

                <!-- QUICK TEST -->
                <div class="rnx-card" style="border-color:#6c63ff33;background:linear-gradient(135deg,#faf9ff,#fff)">
                    <h2>🚀 Fast Generate</h2>
                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                        <input type="hidden" name="action" value="rudnexx_generate_now" />
                        <?php wp_nonce_field('rudnexx_generate_now'); ?>
                        <div style="display:flex;gap:10px;">
                            <input type="text" name="rudnexx_test_keyword" placeholder="Topic..." style="flex:1" required />
                            <button type="submit" class="rnx-btn">⚡ Generate</button>
                        </div>
                    </form>
                </div>
            </div>

            <div class="rnx-sidebar">
                <!-- HELP & SUPPORT -->
                <div class="rnx-card" style="background:#1e293b;color:#f8fafc;border:none">
                    <h2 style="color:#f8fafc;border-color:rgba(255,255,255,0.1)">Need Content Strategy?</h2>
                    <p style="font-size:13px;opacity:0.8;margin-bottom:20px">Let our professional agency handle your AI workflows, SEO optimization, and custom integrations.</p>
                    <a href="https://rudnex.in/contact" target="_blank" style="display:block;text-align:center;background:#6366f1;color:#fff;text-decoration:none;padding:12px;border-radius:8px;font-weight:700">Hire My Agency</a>
                    <div style="margin-top:20px;padding-top:20px;border-top:1px solid rgba(255,255,255,0.1);font-size:12px;opacity:0.6">
                        <p>Version: <?php echo RUDNEXX_VERSION; ?></p>
                        <p>© 2026 Rudnex AI Solutions</p>
                    </div>
                </div>

                <div class="rnx-card">
                    <h2>📡 Autopilot Status</h2>
                    <div style="font-size:13px;display:flex;flex-direction:column;gap:10px">
                        <div style="display:flex;justify-content:space-between; align-items:center; border-bottom:1px solid #f1f5f9; padding-bottom:8px;">
                            <span style="color:#64748b">Queue Items</span>
                            <span style="background:#f1f5f9; padding:2px 8px; border-radius:12px; font-weight:700; color:#475569;"><?php $q = array_filter(explode("\n", get_option('rudnexx_bulk_keywords',''))); echo count($q); ?> items</span>
                        </div>
                        <div style="display:flex;justify-content:space-between; align-items:center; border-bottom:1px solid #f1f5f9; padding-bottom:8px;">
                            <span style="color:#64748b">Last Generation</span>
                            <span style="font-weight:600"><?php echo get_option('rudnexx_last_post_date', 'Never'); ?></span>
                        </div>
                        <div style="display:flex;justify-content:space-between; align-items:center;">
                            <span style="color:#64748b">Next Scheduled Run</span>
                            <?php 
                            $next = wp_next_scheduled('rudnexx_auto_blog_cron'); 
                            $now = time();
                            ?>
                            <span id="rnx-timer-display" style="font-weight:700; color:<?php echo $next ? '#10b981' : '#f43f5e'; ?>; font-variant-numeric: tabular-nums;">
                                <?php echo $next ? 'Calculating...' : 'Not Scheduled'; ?>
                            </span>
                            <?php if ($next): ?>
                            <script>
                                (function() {
                                    var nextRun = <?php echo intval($next); ?>;
                                    var serverNow = <?php echo intval($now); ?>;
                                    var localStart = Math.floor(Date.now() / 1000);
                                    
                                    function updateTimer() {
                                        var localNow = Math.floor(Date.now() / 1000);
                                        var elapsed = localNow - localStart;
                                        var currentServerTime = serverNow + elapsed;
                                        var diff = nextRun - currentServerTime;
                                        
                                        var display = document.getElementById('rnx-timer-display');
                                        if (diff <= 0) {
                                            display.innerText = "Running now...";
                                            display.style.color = "#f59e0b"; // Orange
                                            setTimeout(function() { window.location.reload(); }, 15000);
                                            return;
                                        }
                                        
                                        var m = Math.floor(diff / 60);
                                        var s = diff % 60;
                                        var text = "";
                                        if (m > 60) {
                                            var h = Math.floor(m / 60);
                                            m = m % 60;
                                            text = h + "h " + m + "m " + s + "s";
                                        } else {
                                            text = m + "m " + s + "s";
                                        }
                                        display.innerText = text + " from now";
                                    }
                                    
                                    updateTimer();
                                    setInterval(updateTimer, 1000);
                                })();
                            </script>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>


                <!-- SYNC FIX -->
                <div class="rnx-card" style="border-color:#f43f5e33">
                    <h2 style="color:#f43f5e">🛠️ Sync Troubleshooter</h2>
                    <p style="font-size:12px; color:#64748b; margin-bottom:12px;">If Rudnex SaaS shows a 404/Connection error, click below to reset your site's API routes.</p>
                    <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                        <input type="hidden" name="action" value="rudnexx_fix_sync" />
                        <?php wp_nonce_field('rudnexx_fix_sync'); ?>
                        <button type="submit" class="rnx-btn" style="background:#f43f5e; width:100%; font-size:12px; padding:8px;">Reset API Routes &amp; Fix 404</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script>
    (function () {
        var providerSel = document.getElementById('rnx-provider');
        var allBlocks   = document.querySelectorAll('.rnx-provider-block');
        function show(val) {
            allBlocks.forEach(function (b) { b.style.display = 'none'; b.querySelectorAll('input, select').forEach(function(f){ f.disabled = true; }); });
            var t = document.getElementById('rnx-block-' + val);
            if (t) { t.style.display = 'block'; t.querySelectorAll('input, select').forEach(function(f){ f.disabled = false; }); }
        }
        show(providerSel ? providerSel.value : 'openai');
        if (providerSel) providerSel.addEventListener('change', function () { show(this.value); });

        var imageSel = document.getElementById('rnx-image-source');
        var imgBlocks = document.querySelectorAll('.rnx-img-block');
        function showImg(val) {
            imgBlocks.forEach(function(b){ b.style.display = 'none'; });
            if (val === 'pixabay') document.getElementById('rnx-img-block-pixabay').style.display = 'block';
            if (val === 'dalle' || val === 'stability') document.getElementById('rnx-img-block-gen').style.display = 'block';
        }
        showImg(imageSel ? imageSel.value : 'none');
        if (imageSel) imageSel.addEventListener('change', function() { showImg(this.value); });

        // Knowledge Base Uploader
        var kbBtn = document.getElementById('rnx-kb-upload');
        if (kbBtn) {
            kbBtn.addEventListener('click', function() {
                var fileInput = document.getElementById('rnx-kb-file');
                var titleInput = document.getElementById('rnx-kb-title');
                var msg = document.getElementById('rnx-kb-msg');
                
                if (!fileInput.files.length || !titleInput.value) {
                    msg.style.color = 'red'; msg.innerText = 'Please select a PDF and enter a title.';
                    return;
                }
                
                var file = fileInput.files[0];
                if (file.size > 5 * 1024 * 1024) {
                    msg.style.color = 'red'; msg.innerText = 'File too large. Max 5MB.';
                    return;
                }

                kbBtn.disabled = true; kbBtn.innerText = 'Uploading...';
                msg.style.color = '#64748b'; msg.innerText = 'Processing PDF... please wait.';

                var fd = new FormData();
                fd.append('file', file);
                fd.append('title', titleInput.value);
                // Use the real (server-side) license key stored in hidden field, not the masked display field
                fd.append('licenseKey', document.getElementById('rnx-real-license').value);

                fetch("<?php echo esc_url(RUDNEXX_API_URL); ?>/plugin/knowledge", {
                    method: 'POST',
                    body: fd
                })
                .then(r => r.json())
                .then(data => {
                    if (data.success) {
                        msg.style.color = 'green'; msg.innerText = 'PDF Trained Successfully! It is now part of the AI Knowledge Base.';
                        fileInput.value = ''; titleInput.value = '';
                    } else {
                        throw new Error(data.error || 'Network error');
                    }
                })
                .catch(err => {
                    msg.style.color = 'red'; msg.innerText = 'Upload failed: ' + err.message;
                })
                .finally(() => {
                    kbBtn.disabled = false; kbBtn.innerText = 'Upload PDF';
                });
            });
        }
    })();
    </script>
    <?php
}
