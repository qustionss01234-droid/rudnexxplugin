<?php
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Handle AI Generation
 * Incorporating the 2026-Level System Prompt (Human-Touch Formatting)
 */
function rudnexx_generate_post($topic) {
    $provider = get_option('rudnexx_active_provider', 'openai');
    $api_key = get_option('rudnexx_' . $provider . '_key');
    $license_key = get_option('rudnexx_license_key');
    $domain = $_SERVER['SERVER_NAME'];

    if (empty($api_key) || empty($license_key)) {
        error_log("Rudnexx: Missing API Key for $provider or License Key");
        return new WP_Error('missing_keys', "Missing API Key for $provider or License Key.");
    }

    // Fetch existing post titles so the AI writes a DIFFERENT angle each time
    $existing_posts = get_posts([
        'numberposts'   => 30,
        'post_status'   => 'publish',
        'post_type'     => 'post',
        'orderby'       => 'date',
        'order'         => 'DESC',
    ]);
    $existing_titles = array_map(function($p) { return $p->post_title; }, $existing_posts);

    // Determine RAG search key
    $rag_source  = get_option('rudnexx_rag_source', 'none');
    $serper_key  = get_option('rudnexx_serper_key', '');

    // Fetch Local Context (WooCommerce Products & Business Pages selected in UI)
    $local_context = [];
    
    // 1. Fetch Selected WooCommerce Products
    $saved_products = get_option('rudnexx_selected_products', []);
    if (!empty($saved_products) && class_exists('WooCommerce') && !in_array('none', $saved_products)) {
        $get_all = in_array('all', $saved_products);
        $safe_product_ids = array_filter(array_map('intval', $saved_products)); // Security check
        $products = wc_get_products(['limit' => $get_all ? 50 : -1, 'status' => 'publish', 'include' => $get_all ? [] : $safe_product_ids]);
        
        foreach ($products as $product) {
            $local_context[] = [
                'type'  => 'product',
                'name'  => $product->get_name(),
                'desc'  => strip_tags($product->get_short_description() ?: $product->get_description()),
                'link'  => $product->get_permalink(),
                'price' => $product->get_price_html()
            ];
        }
    }

    // 2. Fetch Selected Business Pages
    $saved_pages = get_option('rudnexx_selected_pages', []);
    if (!empty($saved_pages) && !in_array('none', $saved_pages)) {
        $get_all = in_array('all', $saved_pages);
        $safe_page_ids = array_filter(array_map('intval', $saved_pages)); // Security check
        $pages = get_pages($get_all ? [] : ['include' => $safe_page_ids]);
        
        foreach ($pages as $page) {
            $local_context[] = [
                'type' => 'page',
                'name' => $page->post_title,
                'desc' => strip_tags(substr($page->post_content, 0, 500)), // First 500 chars as context
                'link' => get_permalink($page->ID)
            ];
        }
    }

    // Call the secure Next.js Backend which holds the Secret Prompts
    $request_body = [
        'licenseKey'     => $license_key,
        'domain'         => $domain,
        'topic'          => $topic,
        'provider'       => $provider,
        'apiKey'         => $api_key,
        'model'          => get_option('rudnexx_' . $provider . '_model', ''),
        'existingTitles' => $existing_titles,
        'localContext'   => $local_context,
    ];
    if ($rag_source === 'serper' && !empty($serper_key)) $request_body['serperKey'] = $serper_key;

    $response = wp_remote_post(RUDNEXX_API_URL . '/generate', [
        'timeout' => 120,
        'headers' => ['Content-Type' => 'application/json'],
        'body'    => wp_json_encode($request_body),
    ]);

    if (is_wp_error($response)) {
        error_log("Rudnexx API Connection Error: " . $response->get_error_message());
        return new WP_Error('connection_error', "API Connection Error: " . $response->get_error_message());
    }

    $status_code = wp_remote_retrieve_response_code($response);
    $body = json_decode(wp_remote_retrieve_body($response), true);

    if ($status_code !== 200 || !isset($body['success']) || !$body['success']) {
        $error_msg = isset($body['error']) ? $body['error'] : 'Unknown Next.js API Error';
        error_log("Rudnexx Generation Error [$status_code]: $error_msg");
        return new WP_Error('api_error', "Generation failed: $error_msg");
    }

    $ai_data = $body['post'];

    if (!empty($ai_data['title']) && !empty($ai_data['content'])) {

        // Check for duplicate slug — skip if a post with the same slug exists
        if (!empty($ai_data['slug'])) {
            $existing = get_posts([
                'name'        => sanitize_title($ai_data['slug']),
                'post_type'   => 'post',
                'post_status' => ['publish', 'draft'],
                'numberposts' => 1,
            ]);
            if (!empty($existing)) {
                error_log("Rudnexx: Skipping duplicate post with slug: " . $ai_data['slug']);
                return new WP_Error('duplicate_post', 'A post with this slug already exists. This keyword was skipped.');
            }
        }

        // Sanitize: strip any rogue HTML that could damage the theme layout
        $ai_data['content'] = rudnexx_sanitize_ai_content($ai_data['content']);

        // Run Internal Linker AI
        $ai_data['content'] = rudnexx_internal_linker($ai_data['content']);

        // Run YouTube Auto-Embed
        $ai_data['content'] = rudnexx_youtube_embed($ai_data['content'], $ai_data['title']);

        // Ping the SaaS Dashboard: Log article generation as a live activity event
        wp_remote_post(RUDNEXX_API_URL . '/activity', [
            'timeout'   => 5,
            'blocking'  => false, // Fire-and-forget — doesn't slow down post creation
            'headers'   => ['Content-Type' => 'application/json'],
            'body'      => wp_json_encode([
                'licenseKey' => $license_key,
                'domain'     => $domain,
                'type'       => 'article_generated',
                'title'      => sanitize_text_field($ai_data['title']),
                'model'      => get_option('rudnexx_' . $provider . '_model', 'Unknown'),
            ]),
        ]);

        return $ai_data;

    }

    return new WP_Error('invalid_response', 'The AI returned an invalid or empty response structure.');
}

/**
 * Sanitize AI-generated content to prevent WordPress theme layout damage.
 * Strips rogue HTML, inline styles, and dangerous structural elements.
 */
function rudnexx_sanitize_ai_content($content) {
    if (empty($content)) return $content;

    // Strip <style> and <script> blocks entirely (with content)
    $content = preg_replace('#<style[^>]*>.*?</style>#si', '', $content);
    $content = preg_replace('#<script[^>]*>.*?</script>#si', '', $content);

    // Strip <html>, <head>, <body> wrapper tags (but keep their inner content)
    $content = preg_replace('#</?(?:html|head|body)[^>]*>#i', '', $content);

    // Strip inline style attributes from all elements
    $content = preg_replace('/\s*style\s*=\s*(["\'])[^\'"]*\1/i', '', $content);

    // Replace generic "Introduction" or "Conclusion" bare H2 headings
    $content = preg_replace('#<h2[^>]*>\s*Introduction\s*</h2>#i', '', $content);
    $content = preg_replace('#<h2[^>]*>\s*Conclusion\s*</h2>#i', '<h2>Final Thoughts</h2>', $content);

    return trim($content);
}

/**
 * AI Internal Linker
 * Pseudo-logic: Appends a related post link for demonstration.
 * In production, this queries the WP DB and sends titles back to AI to find contextual match.
 */
function rudnexx_internal_linker($content_html) {
    // 1. Fetch up to 3 recent posts to find a link target
    $recent_posts = wp_get_recent_posts(['numberposts' => 3, 'post_status' => 'publish']);
    
    if (empty($recent_posts)) {
        return $content_html;
    }

    // Pick a random recent post to link to (helps distribute link juice)
    $target_post = $recent_posts[array_rand($recent_posts)];
    $link = get_permalink($target_post['ID']);
    $title = $target_post['post_title'];

    // 2. Build the "Related Read" HTML block
    $link_block = "
    <div style='background: #f8fafc; padding: 15px 20px; border-left: 5px solid #3b82f6; margin: 30px 0; border-radius: 0 8px 8px 0; box-shadow: 0 1px 3px rgba(0,0,0,0.05); font-family: system-ui, sans-serif;'>
        <b style='color: #1e293b; font-size: 14px; text-transform: uppercase; letter-spacing: 0.5px;'>Related Review:</b><br/>
        <a href='" . esc_url($link) . "' style='color: #2563eb; text-decoration: none; font-size: 18px; font-weight: 600; line-height: 1.4; display: inline-block; margin-top: 5px;'>" . esc_html($title) . "</a>
    </div>
    ";

    // 3. Inject it naturally into the middle of the article
    // Find all paragraph tags
    $paragraphs = explode('</p>', $content_html);
    $total_paragraphs = count($paragraphs);

    if ($total_paragraphs > 4) {
        // Insert after the 3rd paragraph
        $insert_position = 3;
        array_splice($paragraphs, $insert_position, 0, $link_block);
        $content_html = implode('</p>', $paragraphs);
    } else {
        // If it's a very short article, just append it
        $content_html .= $link_block;
    }

    return $content_html;
}

/**
 * Hybrid Featured Image Automation
 * Supports: Pixabay stock search, OpenAI DALL-E 3, Stability AI
 */
function rudnexx_set_featured_image($post_id, $ai_data) {
    $source       = get_option('rudnexx_image_source', 'none');
    $image_url    = null;

    if ($source === 'none') return;

    require_once ABSPATH . 'wp-admin/includes/media.php';
    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/image.php';

    if ($source === 'pixabay') {
        // --- Pixabay Stock Photo Search ---
        $key     = get_option('rudnexx_pixabay_key');
        $keyword = !empty($ai_data['image_keyword']) ? urlencode($ai_data['image_keyword']) : 'technology';
        if (empty($key)) return;
        $res  = wp_remote_get("https://pixabay.com/api/?key={$key}&q={$keyword}&image_type=photo&orientation=horizontal&per_page=5&safesearch=true", ['timeout' => 20]);
        if (is_wp_error($res)) return;
        $data = json_decode(wp_remote_retrieve_body($res), true);
        if (!empty($data['hits'][0]['largeImageURL'])) {
            $image_url = $data['hits'][0]['largeImageURL'];
        }

    } elseif ($source === 'dalle') {
        // --- OpenAI DALL-E 3 AI Image Generation ---
        $key    = get_option('rudnexx_image_gen_key');
        $prompt = !empty($ai_data['image_prompt']) ? $ai_data['image_prompt'] : ('Professional photo for blog post about: ' . ($ai_data['title'] ?? 'technology'));
        if (empty($key)) return;
        $res = wp_remote_post('https://api.openai.com/v1/images/generations', [
            'timeout' => 60,
            'headers' => ['Content-Type' => 'application/json', 'Authorization' => "Bearer {$key}"],
            'body'    => wp_json_encode(['model' => 'dall-e-3', 'prompt' => $prompt, 'n' => 1, 'size' => '1792x1024', 'quality' => 'standard']),
        ]);
        if (is_wp_error($res)) return;
        $data = json_decode(wp_remote_retrieve_body($res), true);
        if (!empty($data['data'][0]['url'])) {
            $image_url = $data['data'][0]['url'];
        }

    } elseif ($source === 'stability') {
        // --- Stability AI (stable-image-ultra) ---
        $key    = get_option('rudnexx_image_gen_key');
        $prompt = !empty($ai_data['image_prompt']) ? $ai_data['image_prompt'] : ('Professional blog header image for: ' . ($ai_data['title'] ?? 'technology'));
        if (empty($key)) return;
        $res = wp_remote_post('https://api.stability.ai/v2beta/stable-image/generate/ultra', [
            'timeout' => 90,
            'headers' => ['Authorization' => "Bearer {$key}", 'Accept' => 'image/*'],
            'body'    => ['prompt' => $prompt, 'aspect_ratio' => '16:9', 'output_format' => 'webp'],
        ]);
        if (is_wp_error($res) || wp_remote_retrieve_response_code($res) !== 200) return;
        // Stability returns raw image bytes — save to a temp file
        $image_data = wp_remote_retrieve_body($res);
        $tmp_file = wp_tempnam('rnx_img.webp');
        file_put_contents($tmp_file, $image_data);
        $file_array = ['name' => sanitize_title($ai_data['title'] ?? 'rudnexx') . '.webp', 'tmp_name' => $tmp_file];
        $media_id = media_handle_sideload($file_array, $post_id, $ai_data['title'] ?? '');
        if (!is_wp_error($media_id)) set_post_thumbnail($post_id, $media_id);
        return;
    }

    // For Pixabay and DALL-E that return a URL
    if ($image_url) {
        $media_id = media_sideload_image($image_url, $post_id, $ai_data['title'] ?? '', 'id');
        if (!is_wp_error($media_id)) {
            set_post_thumbnail($post_id, $media_id);
        }
    }
}

/**
 * YouTube Auto-Embed Finder
 * Scrapes YouTube search for the keyword and appends a responsive video embed.
 */
function rudnexx_youtube_embed($content_html, $keyword) {
    if (get_option('rudnexx_youtube_embed') !== 'enabled') {
        return $content_html; // Disabled
    }

    if (empty($keyword)) return $content_html;

    $search_query = urlencode(sanitize_text_field($keyword));
    $search_url = "https://www.youtube.com/results?search_query=" . $search_query;

    $response = wp_remote_get($search_url, [
        'timeout' => 15,
        'headers' => [
            'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) width/1920 Safari/537.36'
        ]
    ]);

    if (is_wp_error($response)) {
        return $content_html;
    }

    $body = wp_remote_retrieve_body($response);
    
    // Scrape the first video ID from the ytInitialData JSON blob
    preg_match('/"videoId":"([a-zA-Z0-9_-]{11})"/', $body, $matches);

    if (!empty($matches[1])) {
        $video_id = $matches[1];
        $video_url = "https://www.youtube.com/watch?v=" . $video_id;

        // Build the WordPress Core Video Embed Block HTML
        $embed_block = "
        <!-- wp:core-embed/youtube {\"url\":\"{$video_url}\",\"type\":\"video\",\"providerNameSlug\":\"youtube\",\"className\":\"wp-embed-aspect-16-9 wp-has-aspect-ratio\"} -->
        <figure class=\"wp-block-embed is-type-video is-provider-youtube wp-block-embed-youtube wp-embed-aspect-16-9 wp-has-aspect-ratio\" style=\"margin: 40px 0;\">
            <div class=\"wp-block-embed__wrapper\">
                {$video_url}
            </div>
            <figcaption class=\"wp-element-caption\">Watch this related video about " . esc_html($keyword) . " for more insights.</figcaption>
        </figure>
        <!-- /wp:core-embed/youtube -->";

        // Try to insert in the middle of the article
        $headings_count = substr_count($content_html, '<!-- wp:heading');
        if ($headings_count >= 2) {
            $middle = max(1, floor($headings_count / 2));
            $parts = explode('<!-- wp:heading', $content_html);
            $new_content_html = $parts[0];
            for ($i = 1; $i < count($parts); $i++) {
                if ($i == $middle) {
                    $new_content_html .= "\n\n" . $embed_block . "\n\n";
                }
                $new_content_html .= '<!-- wp:heading' . $parts[$i];
            }
            return $new_content_html;
        }

        // Fallback: Append to the bottom of the article if there aren't enough headings
        return $content_html . "\n\n" . $embed_block;
    }

    return $content_html;
}
