<?php
if (!defined('ABSPATH')) { exit; }

function rudnexx_get_providers() {
    return [
        'openai' => [
            'label' => 'OpenAI',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_openai_key',
            'key_link'   => 'https://platform.openai.com/api-keys',
            'models' => [
                'gpt-5' => 'gpt-5 [Flagship]',
                'gpt-5-mini' => 'gpt-5-mini [Flagship]',
                'gpt-5-nano' => 'gpt-5-nano [Flagship]',
                'gpt-4o' => 'gpt-4o [Highlight]',
                'gpt-4o-mini' => 'gpt-4o-mini [Highlight]',
                'gpt-4.1' => 'gpt-4.1',
                'gpt-4.1-mini' => 'gpt-4.1-mini',
                'gpt-4.1-nano' => 'gpt-4.1-nano',
                'o3' => 'o3',
                'o3-pro' => 'o3-pro',
                'o3-mini' => 'o3-mini',
                'o4-mini' => 'o4-mini',
                'o4-mini-high' => 'o4-mini-high',
                'gpt-oss-20b' => 'gpt-oss-20b',
                'gpt-oss-120b' => 'gpt-oss-120b',
                'whisper-1' => 'whisper-1',
                'dall-e-3' => 'dall-e-3',
                'gpt-image-1' => 'gpt-image-1',
                'text-embedding-3-large' => 'text-embedding-3-large',
                'text-embedding-3-small' => 'text-embedding-3-small'
            ],
        ],
        'anthropic' => [
            'label' => 'Anthropic Claude',
            'key_placeholder' => 'sk-ant-...',
            'key_option' => 'rudnexx_anthropic_key',
            'key_link'   => 'https://console.anthropic.com/keys',
            'models' => [
                'claude-opus-4-6-20260205' => 'claude-opus-4-6-20260205 [Flagship]',
                'claude-sonnet-4-6-20260217' => 'claude-sonnet-4-6-20260217 [Flagship]',
                'claude-opus-4-5-20251124' => 'claude-opus-4-5-20251124 [Highlight]',
                'claude-sonnet-4-5-20250929' => 'claude-sonnet-4-5-20250929 [Highlight]',
                'claude-haiku-4-5-20251001' => 'claude-haiku-4-5-20251001',
                'claude-opus-4-20250514' => 'claude-opus-4-20250514',
                'claude-sonnet-4-20250514' => 'claude-sonnet-4-20250514',
                'claude-sonnet-4-1-20250721' => 'claude-sonnet-4-1-20250721',
                'claude-3-7-sonnet-20250219' => 'claude-3-7-sonnet-20250219',
                'claude-3-5-haiku-20241022' => 'claude-3-5-haiku-20241022',
                'claude-opus-4-6' => 'claude-opus-4-6',
                'claude-sonnet-4-6' => 'claude-sonnet-4-6'
            ],
        ],
        'gemini' => [
            'label' => 'Google Gemini (AI Studio)',
            'key_placeholder' => 'AIza...',
            'key_option' => 'rudnexx_gemini_key',
            'key_link'   => 'https://aistudio.google.com/app/apikey',
            'models' => [
                'gemini-3.1-pro' => 'gemini-3.1-pro [Flagship]',
                'gemini-3.1-flash' => 'gemini-3.1-flash [Flagship]',
                'gemini-3.1-flash-lite' => 'gemini-3.1-flash-lite [Flagship]',
                'gemini-2.5-pro' => 'gemini-2.5-pro [Highlight]',
                'gemini-2.5-flash' => 'gemini-2.5-flash [Flagship Highlight FREE]',
                'gemini-2.5-flash-lite' => 'gemini-2.5-flash-lite [Flagship FREE]',
                'gemini-2.0-flash' => 'gemini-2.0-flash',
                'gemini-2.0-flash-lite' => 'gemini-2.0-flash-lite',
                'gemini-2.5-flash-latest' => 'gemini-2.5-flash-latest',
                'gemini-2.5-pro-latest' => 'gemini-2.5-pro-latest',
                'gemini-embedding-001' => 'gemini-embedding-001',
                'imagen-4-generate' => 'imagen-4-generate',
                'imagen-3-generate-002' => 'imagen-3-generate-002',
                'veo-3.1-generate' => 'veo-3.1-generate'
            ],
        ],
        'groq' => [
            'label' => 'Groq Cloud',
            'key_placeholder' => 'gsk_...',
            'key_option' => 'rudnexx_groq_key',
            'key_link'   => 'https://console.groq.com/keys',
            'models' => [
                'llama-3.3-70b-versatile' => 'llama-3.3-70b-versatile [Flagship FREE]',
                'llama-3.1-8b-instant' => 'llama-3.1-8b-instant [Flagship Highlight FREE]',
                'llama3-70b-8192' => 'llama3-70b-8192 [Flagship FREE]',
                'llama3-8b-8192' => 'llama3-8b-8192 [Flagship FREE]',
                'mixtral-8x7b-32768' => 'mixtral-8x7b-32768 [Flagship FREE]',
                'gemma2-9b-it' => 'gemma2-9b-it [Flagship FREE]',
                'gemma-7b-it' => 'gemma-7b-it [Flagship FREE]',
                'deepseek-r1-distill-llama-70b' => 'deepseek-r1-distill-llama-70b [Flagship FREE]',
                'deepseek-r1-distill-qwen-32b' => 'deepseek-r1-distill-qwen-32b [Flagship FREE]',
                'llama-3.2-11b-vision-preview' => 'llama-3.2-11b-vision-preview [Flagship FREE]',
                'llama-3.2-90b-vision-preview' => 'llama-3.2-90b-vision-preview [Flagship FREE]',
                'qwen-qwq-32b' => 'qwen-qwq-32b [Flagship FREE]',
                'compound-beta' => 'compound-beta [Flagship FREE]',
                'whisper-large-v3' => 'whisper-large-v3 [Flagship FREE]'
            ],
        ],
        'openrouter' => [
            'label' => 'OpenRouter',
            'key_placeholder' => 'sk-or-...',
            'key_option' => 'rudnexx_openrouter_key',
            'key_link'   => 'https://openrouter.ai/keys',
            'models' => [
                'meta-llama/llama-4-maverick:free' => 'meta-llama/llama-4-maverick:free [Flagship FREE]',
                'meta-llama/llama-4-scout:free' => 'meta-llama/llama-4-scout:free [Flagship FREE]',
                'meta-llama/llama-3.3-70b-instruct:free' => 'meta-llama/llama-3.3-70b-instruct:free [Flagship Highlight FREE]',
                'google/gemma-3-27b-it:free' => 'google/gemma-3-27b-it:free [Flagship FREE]',
                'microsoft/phi-4:free' => 'microsoft/phi-4:free [Flagship FREE]',
                'deepseek/deepseek-r1:free' => 'deepseek/deepseek-r1:free [Flagship FREE]',
                'deepseek/deepseek-chat-v3-0324:free' => 'deepseek/deepseek-chat-v3-0324:free [Flagship FREE]',
                'qwen/qwen3-8b:free' => 'qwen/qwen3-8b:free [Flagship FREE]',
                'x-ai/grok-3-mini:free' => 'x-ai/grok-3-mini:free [Flagship FREE]',
                'mistralai/mistral-7b-instruct:free' => 'mistralai/mistral-7b-instruct:free [Flagship FREE]',
                'x-ai/grok-4-fast:free' => 'x-ai/grok-4-fast:free [Flagship FREE]',
                '...200+ paid models' => '...200+ paid models'
            ],
        ],
        'mistral' => [
            'label' => 'Mistral AI',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_mistral_key',
            'key_link'   => 'https://console.mistral.ai/api-keys',
            'models' => [
                'mistral-large-latest' => 'mistral-large-latest [Flagship]',
                'mistral-small-latest' => 'mistral-small-latest [Flagship Highlight FREE]',
                'mistral-medium-latest' => 'mistral-medium-latest',
                'open-mistral-nemo' => 'open-mistral-nemo',
                'codestral-latest' => 'codestral-latest',
                'devstral-small-latest' => 'devstral-small-latest',
                'pixtral-12b-2409' => 'pixtral-12b-2409',
                'pixtral-large-latest' => 'pixtral-large-latest',
                'mistral-small-3.1-24b-instruct' => 'mistral-small-3.1-24b-instruct',
                'mistral-embed' => 'mistral-embed'
            ],
        ],
        'cerebras-ai' => [
            'label' => 'Cerebras AI',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_cerebras-ai_key',
            'key_link'   => 'https://cloud.cerebras.ai',
            'models' => [
                'llama-3.3-70b' => 'llama-3.3-70b [Flagship FREE]',
                'llama-3.1-8b' => 'llama-3.1-8b [Flagship Highlight FREE]',
                'qwen-3-32b' => 'qwen-3-32b [Flagship FREE]',
                'llama-4-scout-17b-16e' => 'llama-4-scout-17b-16e [Flagship FREE]',
                'deepseek-r1-distill-llama-70b' => 'deepseek-r1-distill-llama-70b [Flagship FREE]'
            ],
        ],
        'nvidia-nim' => [
            'label' => 'NVIDIA NIM',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_nvidia-nim_key',
            'key_link'   => 'https://build.nvidia.com',
            'models' => [
                'openai/gpt-oss-120b' => 'openai/gpt-oss-120b [Flagship FREE]',
                'meta/llama-4-maverick-17b-128e-instruct' => 'meta/llama-4-maverick-17b-128e-instruct [Flagship Highlight FREE]',
                'meta/llama-3.3-70b-instruct' => 'meta/llama-3.3-70b-instruct [Flagship FREE]',
                'meta/llama-3.1-405b-instruct' => 'meta/llama-3.1-405b-instruct [Flagship FREE]',
                'mistralai/mistral-small-3.1-24b-instruct' => 'mistralai/mistral-small-3.1-24b-instruct [Flagship FREE]',
                'microsoft/phi-4' => 'microsoft/phi-4 [Flagship FREE]',
                'qwen/qwen3-235b-a22b' => 'qwen/qwen3-235b-a22b [Flagship FREE]',
                'deepseek-ai/deepseek-r1' => 'deepseek-ai/deepseek-r1 [Flagship FREE]',
                'google/gemma-3-27b-it' => 'google/gemma-3-27b-it [Flagship FREE]',
                'writer/palmyra-x5' => 'writer/palmyra-x5 [Flagship FREE]'
            ],
        ],
        'xai-grok' => [
            'label' => 'xAI (Grok)',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_xai-grok_key',
            'key_link'   => 'https://console.x.ai',
            'models' => [
                'grok-4' => 'grok-4 [Flagship]',
                'grok-4-fast' => 'grok-4-fast [Flagship]',
                'grok-3' => 'grok-3 [Highlight]',
                'grok-3-mini' => 'grok-3-mini [Highlight]',
                'grok-3-fast' => 'grok-3-fast',
                'grok-3-mini-fast' => 'grok-3-mini-fast',
                'grok-2-1212' => 'grok-2-1212',
                'grok-2-vision-1212' => 'grok-2-vision-1212',
                'grok-beta' => 'grok-beta'
            ],
        ],
        'together-ai' => [
            'label' => 'Together AI',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_together-ai_key',
            'key_link'   => 'https://api.together.xyz/settings/api-keys',
            'models' => [
                'meta-llama/Llama-4-Maverick-17B-128E-Instruct-FP8' => 'meta-llama/Llama-4-Maverick-17B-128E-Instruct-FP8 [Flagship]',
                'meta-llama/Llama-3.3-70B-Instruct-Turbo-Free' => 'meta-llama/Llama-3.3-70B-Instruct-Turbo-Free [Highlight]',
                'DeepSeek-V3-Free' => 'DeepSeek-V3-Free [Flagship FREE]',
                'Qwen3-235B-A22B-Instruct-Free' => 'Qwen3-235B-A22B-Instruct-Free [Flagship FREE]',
                'meta-llama/Llama-3.1-405B-Instruct-Turbo' => 'meta-llama/Llama-3.1-405B-Instruct-Turbo',
                'black-forest-labs/FLUX.1-schnell-Free' => 'black-forest-labs/FLUX.1-schnell-Free',
                'stabilityai/stable-diffusion-xl-base-1.0' => 'stabilityai/stable-diffusion-xl-base-1.0'
            ],
        ],
        'cohere' => [
            'label' => 'Cohere',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_cohere_key',
            'key_link'   => 'https://dashboard.cohere.com/api-keys',
            'models' => [
                'command-r-plus' => 'command-r-plus [Flagship]',
                'command-r-plus-08-2024' => 'command-r-plus-08-2024 [Flagship]',
                'command-r' => 'command-r [Highlight]',
                'command-r-08-2024' => 'command-r-08-2024',
                'command-r7b-12-2024' => 'command-r7b-12-2024',
                'c4ai-aya-expanse-8b' => 'c4ai-aya-expanse-8b',
                'c4ai-aya-expanse-32b' => 'c4ai-aya-expanse-32b',
                'embed-english-v3.0' => 'embed-english-v3.0',
                'embed-multilingual-v3.0' => 'embed-multilingual-v3.0',
                'rerank-english-v3.0' => 'rerank-english-v3.0'
            ],
        ],
        'hugging-face' => [
            'label' => 'Hugging Face',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_hugging-face_key',
            'key_link'   => 'https://huggingface.co/settings/tokens',
            'models' => [
                'meta-llama/Llama-3.2-3B-Instruct' => 'meta-llama/Llama-3.2-3B-Instruct [Flagship Highlight FREE]',
                'meta-llama/Llama-3.1-8B-Instruct' => 'meta-llama/Llama-3.1-8B-Instruct [Flagship FREE]',
                'google/gemma-3-27b-it' => 'google/gemma-3-27b-it [Flagship FREE]',
                'mistralai/Mistral-7B-Instruct-v0.3' => 'mistralai/Mistral-7B-Instruct-v0.3 [Flagship FREE]',
                'microsoft/Phi-4' => 'microsoft/Phi-4 [Flagship FREE]',
                'Qwen/Qwen2.5-72B-Instruct' => 'Qwen/Qwen2.5-72B-Instruct [Flagship FREE]',
                'tiiuae/falcon-40b-instruct' => 'tiiuae/falcon-40b-instruct [Flagship FREE]'
            ],
        ],
        'fireworks-ai' => [
            'label' => 'Fireworks AI',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_fireworks-ai_key',
            'key_link'   => 'https://fireworks.ai/account/api-keys',
            'models' => [
                'accounts/fireworks/models/llama4-maverick-instruct-basic' => 'accounts/fireworks/models/llama4-maverick-instruct-basic [Flagship]',
                'accounts/fireworks/models/llama-v3p3-70b-instruct' => 'accounts/fireworks/models/llama-v3p3-70b-instruct [Highlight]',
                'accounts/fireworks/models/deepseek-v3' => 'accounts/fireworks/models/deepseek-v3',
                'accounts/fireworks/models/qwen3-235b-a22b' => 'accounts/fireworks/models/qwen3-235b-a22b',
                'accounts/fireworks/models/mixtral-8x22b-instruct' => 'accounts/fireworks/models/mixtral-8x22b-instruct',
                'accounts/fireworks/models/phi-4' => 'accounts/fireworks/models/phi-4'
            ],
        ],
        'sambanova-cloud' => [
            'label' => 'SambaNova Cloud',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_sambanova-cloud_key',
            'key_link'   => 'https://cloud.sambanova.ai/apis',
            'models' => [
                'Meta-Llama-3.1-405B-Instruct' => 'Meta-Llama-3.1-405B-Instruct [Flagship FREE]',
                'Meta-Llama-3.3-70B-Instruct' => 'Meta-Llama-3.3-70B-Instruct [Flagship Highlight FREE]',
                'Meta-Llama-3.1-8B-Instruct' => 'Meta-Llama-3.1-8B-Instruct [Flagship FREE]',
                'DeepSeek-R1' => 'DeepSeek-R1 [Flagship FREE]',
                'DeepSeek-V3-0324' => 'DeepSeek-V3-0324 [Flagship FREE]',
                'Qwen3-32B' => 'Qwen3-32B [Flagship FREE]',
                'Llama-4-Scout-17B-16E-Instruct' => 'Llama-4-Scout-17B-16E-Instruct [Flagship FREE]',
                'Llama-4-Maverick-17B-128E-Instruct' => 'Llama-4-Maverick-17B-128E-Instruct [Flagship FREE]'
            ],
        ],
        'hyperbolic' => [
            'label' => 'Hyperbolic',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_hyperbolic_key',
            'key_link'   => 'https://app.hyperbolic.xyz/settings',
            'models' => [
                'meta-llama/Llama-3.1-405B-Instruct' => 'meta-llama/Llama-3.1-405B-Instruct [Flagship]',
                'meta-llama/Llama-3.3-70B-Instruct' => 'meta-llama/Llama-3.3-70B-Instruct [Highlight]',
                'deepseek-ai/DeepSeek-R1' => 'deepseek-ai/DeepSeek-R1',
                'Qwen/Qwen2.5-72B-Instruct' => 'Qwen/Qwen2.5-72B-Instruct',
                'NovaSky-Berkeley/Sky-T1-32B-Preview' => 'NovaSky-Berkeley/Sky-T1-32B-Preview'
            ],
        ],
        'github-models' => [
            'label' => 'GitHub Models',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_github-models_key',
            'key_link'   => 'https://github.com/settings/tokens',
            'models' => [
                'gpt-4o' => 'gpt-4o [Flagship FREE]',
                'claude-3-5-sonnet' => 'claude-3-5-sonnet [Flagship FREE]',
                'Meta-Llama-3.1-70B-Instruct' => 'Meta-Llama-3.1-70B-Instruct [Flagship FREE]',
                'Mistral-small' => 'Mistral-small [Flagship FREE]',
                'Phi-3.5-MoE-instruct' => 'Phi-3.5-MoE-instruct [Flagship FREE]',
                'Cohere-command-r' => 'Cohere-command-r [Flagship FREE]'
            ],
        ],
        'cloudflare-workers-ai' => [
            'label' => 'Cloudflare Workers AI',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_cloudflare-workers-ai_key',
            'key_link'   => 'https://dash.cloudflare.com/profile/api-tokens',
            'models' => [
                '@cf/openai/gpt-oss-120b' => '@cf/openai/gpt-oss-120b [Flagship FREE]',
                '@cf/meta/llama-4-scout-17b-16e-instruct' => '@cf/meta/llama-4-scout-17b-16e-instruct [Flagship Highlight FREE]',
                '@cf/meta/llama-3.3-70b-instruct-fp8-fast' => '@cf/meta/llama-3.3-70b-instruct-fp8-fast [Flagship FREE]',
                '@cf/mistralai/mistral-small-3.1-24b-instruct' => '@cf/mistralai/mistral-small-3.1-24b-instruct [Flagship FREE]',
                '@cf/microsoft/phi-4' => '@cf/microsoft/phi-4 [Flagship FREE]',
                '@cf/google/gemma-3-12b-it' => '@cf/google/gemma-3-12b-it [Flagship FREE]',
                '@cf/deepseek-ai/deepseek-r1-distill-qwen-32b' => '@cf/deepseek-ai/deepseek-r1-distill-qwen-32b [Flagship FREE]'
            ],
        ],
        'zhipu-ai-glm' => [
            'label' => 'Zhipu AI (GLM)',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_zhipu-ai-glm_key',
            'key_link'   => 'https://open.bigmodel.cn/usercenter/apikeys',
            'models' => [
                'glm-z1-flash' => 'glm-z1-flash [Flagship]',
                'glm-4-flash' => 'glm-4-flash [Flagship Highlight FREE]',
                'glm-4-plus' => 'glm-4-plus',
                'glm-4-long' => 'glm-4-long',
                'glm-4v-plus' => 'glm-4v-plus'
            ],
        ],
        'qwen-alibaba-cloud' => [
            'label' => 'Qwen / Alibaba Cloud',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_qwen-alibaba-cloud_key',
            'key_link'   => 'https://bailian.console.aliyun.com',
            'models' => [
                'qwen3-235b-a22b' => 'qwen3-235b-a22b [Flagship]',
                'qwen3-235b-a22b-thinking-2507' => 'qwen3-235b-a22b-thinking-2507 [Flagship]',
                'qwen3-32b' => 'qwen3-32b [Highlight]',
                'qwen3-30b-a3b' => 'qwen3-30b-a3b [Highlight]',
                'qwen3-14b' => 'qwen3-14b',
                'qwen3-8b' => 'qwen3-8b',
                'qwen3-4b' => 'qwen3-4b',
                'qwen2.5-72b-instruct' => 'qwen2.5-72b-instruct',
                'qwen2.5-32b-instruct' => 'qwen2.5-32b-instruct',
                'qwq-32b' => 'qwq-32b',
                'qwen-vl-max-latest' => 'qwen-vl-max-latest'
            ],
        ],
        'novita-ai' => [
            'label' => 'Novita AI',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_novita-ai_key',
            'key_link'   => 'https://novita.ai/settings/key-management',
            'models' => [
                'meta-llama/llama-3.1-70b-instruct' => 'meta-llama/llama-3.1-70b-instruct [Highlight]',
                'deepseek-ai/deepseek-r1' => 'deepseek-ai/deepseek-r1',
                'Qwen/Qwen2.5-72B-Instruct' => 'Qwen/Qwen2.5-72B-Instruct',
                'stabilityai/stable-diffusion-xl-base-1.0' => 'stabilityai/stable-diffusion-xl-base-1.0'
            ],
        ],
        'scaleway-europe' => [
            'label' => 'Scaleway (Europe)',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_scaleway-europe_key',
            'key_link'   => 'https://console.scaleway.com/iam/api-keys',
            'models' => [
                'llama-3.3-70b-instruct' => 'llama-3.3-70b-instruct [Flagship Highlight FREE]',
                'mistral-nemo-instruct-2407' => 'mistral-nemo-instruct-2407 [Flagship FREE]',
                'qwen2.5-coder-32b-instruct' => 'qwen2.5-coder-32b-instruct [Flagship FREE]',
                'pixtral-12b' => 'pixtral-12b [Flagship FREE]'
            ],
        ],
        'baidu-ernie-qianfan' => [
            'label' => 'Baidu ERNIE (Qianfan)',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_baidu-ernie-qianfan_key',
            'key_link'   => 'https://console.bce.baidu.com/qianfan/ais/console/applicationConsole/application',
            'models' => [
                'ernie-4.5-turbo-128k' => 'ernie-4.5-turbo-128k [Flagship]',
                'ernie-4.0-turbo-128k' => 'ernie-4.0-turbo-128k [Highlight]',
                'ernie-speed-128k' => 'ernie-speed-128k [Flagship FREE]',
                'ernie-lite-8k' => 'ernie-lite-8k [Flagship FREE]',
                'ernie-tiny-8k' => 'ernie-tiny-8k [Flagship FREE]'
            ],
        ],
        'bytedance-doubao' => [
            'label' => 'ByteDance (Doubao)',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_bytedance-doubao_key',
            'key_link'   => 'https://console.volcengine.com/ark/region:ark+cn-beijing/apiKey',
            'models' => [
                'doubao-pro-256k' => 'doubao-pro-256k [Flagship]',
                'doubao-pro-32k' => 'doubao-pro-32k [Flagship Highlight FREE]',
                'doubao-lite-32k' => 'doubao-lite-32k [Flagship FREE]',
                'doubao-embedding' => 'doubao-embedding'
            ],
        ],
        'moonshot-ai-kimi' => [
            'label' => 'Moonshot AI (Kimi)',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_moonshot-ai-kimi_key',
            'key_link'   => 'https://platform.moonshot.cn/console/api-keys',
            'models' => [
                'kimi-k2-0711-preview' => 'kimi-k2-0711-preview [Flagship]',
                'moonshot-v1-128k' => 'moonshot-v1-128k [Highlight]',
                'moonshot-v1-32k' => 'moonshot-v1-32k',
                'moonshot-v1-8k' => 'moonshot-v1-8k'
            ],
        ],
        'minimax' => [
            'label' => 'MiniMax',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_minimax_key',
            'key_link'   => 'https://platform.minimaxi.com/user-center/basic-information/interface-key',
            'models' => [
                'MiniMax-M1-40k' => 'MiniMax-M1-40k [Flagship]',
                'MiniMax-Text-01' => 'MiniMax-Text-01 [Highlight]',
                'abab6.5s-chat' => 'abab6.5s-chat',
                'abab5.5-chat' => 'abab5.5-chat'
            ],
        ],
        'tencent-hunyuan' => [
            'label' => 'Tencent Hunyuan',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_tencent-hunyuan_key',
            'key_link'   => 'https://console.cloud.tencent.com/cam/capi',
            'models' => [
                'hunyuan-pro' => 'hunyuan-pro [Flagship]',
                'hunyuan-turbos' => 'hunyuan-turbos [Flagship Highlight FREE]',
                'hunyuan-standard' => 'hunyuan-standard [Flagship FREE]',
                'hunyuan-lite' => 'hunyuan-lite [Flagship FREE]'
            ],
        ],
        '01-ai-yi-models' => [
            'label' => '01.AI (Yi Models)',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_01-ai-yi-models_key',
            'key_link'   => 'https://platform.lingyiwanwu.com/apikeys',
            'models' => [
                'yi-lightning' => 'yi-lightning [Flagship]',
                'yi-large' => 'yi-large [Highlight]',
                'yi-medium' => 'yi-medium',
                'yi-spark' => 'yi-spark',
                'yi-vision' => 'yi-vision'
            ],
        ],
        'stepfun-step-ai' => [
            'label' => 'StepFun (Step AI)',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_stepfun-step-ai_key',
            'key_link'   => 'https://platform.stepfun.com/account-info',
            'models' => [
                'step-2-16k' => 'step-2-16k [Flagship]',
                'step-1-200k' => 'step-1-200k [Highlight]',
                'step-1v-32k' => 'step-1v-32k'
            ],
        ],
        'upstage-solar' => [
            'label' => 'Upstage (Solar)',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_upstage-solar_key',
            'key_link'   => 'https://console.upstage.ai/api-keys',
            'models' => [
                'solar-pro' => 'solar-pro [Flagship]',
                'solar-mini' => 'solar-mini [Highlight]',
                'solar-docvision' => 'solar-docvision'
            ],
        ],
        'featherless-ai' => [
            'label' => 'Featherless AI',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_featherless-ai_key',
            'key_link'   => 'https://featherless.ai/account/api-keys',
            'models' => [
                'meta-llama/Llama-3.3-70B-Instruct' => 'meta-llama/Llama-3.3-70B-Instruct',
                'Qwen/Qwen2.5-72B-Instruct' => 'Qwen/Qwen2.5-72B-Instruct',
                'CohereForAI/c4ai-command-r-plus' => 'CohereForAI/c4ai-command-r-plus',
                'Any HuggingFace model' => 'Any HuggingFace model'
            ],
        ],
        'deepseek' => [
            'label' => 'DeepSeek',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_deepseek_key',
            'key_link'   => 'https://platform.deepseek.com/api_keys',
            'models' => [
                'deepseek-chat' => 'deepseek-chat [Flagship]',
                'deepseek-reasoner' => 'deepseek-reasoner [Flagship]',
                'deepseek-chat-v3-0324' => 'deepseek-chat-v3-0324 [Highlight]',
                'deepseek-r1' => 'deepseek-r1',
                'deepseek-r1-0528' => 'deepseek-r1-0528',
                'deepseek-coder' => 'deepseek-coder',
                'deepseek-v2.5' => 'deepseek-v2.5'
            ],
        ],
        'perplexity-sonar' => [
            'label' => 'Perplexity (Sonar)',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_perplexity-sonar_key',
            'key_link'   => 'https://www.perplexity.ai/settings/api',
            'models' => [
                'sonar-pro' => 'sonar-pro [Flagship]',
                'sonar' => 'sonar [Highlight]',
                'sonar-reasoning-pro' => 'sonar-reasoning-pro',
                'sonar-reasoning' => 'sonar-reasoning',
                'sonar-deep-research' => 'sonar-deep-research',
                'r1-1776' => 'r1-1776'
            ],
        ],
        'ai21-labs-jamba' => [
            'label' => 'AI21 Labs (Jamba)',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_ai21-labs-jamba_key',
            'key_link'   => 'https://studio.ai21.com/account/api-key',
            'models' => [
                'jamba-1.6-large' => 'jamba-1.6-large [Flagship]',
                'jamba-1.6-mini' => 'jamba-1.6-mini [Highlight]',
                'jamba-1.5-large' => 'jamba-1.5-large',
                'jamba-1.5-mini' => 'jamba-1.5-mini'
            ],
        ],
        'writer-palmyra' => [
            'label' => 'Writer (Palmyra)',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_writer-palmyra_key',
            'key_link'   => 'https://dev.writer.com/api-keys',
            'models' => [
                'palmyra-x5' => 'palmyra-x5 [Flagship]',
                'palmyra-x4' => 'palmyra-x4 [Highlight]',
                'palmyra-x-004' => 'palmyra-x-004',
                'palmyra-med' => 'palmyra-med',
                'palmyra-fin' => 'palmyra-fin',
                'palmyra-vision' => 'palmyra-vision'
            ],
        ],
        'amazon-bedrock' => [
            'label' => 'Amazon Bedrock',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_amazon-bedrock_key',
            'key_link'   => 'https://aws.amazon.com/console',
            'models' => [
                'anthropic.claude-sonnet-4-6' => 'anthropic.claude-sonnet-4-6 [Flagship]',
                'anthropic.claude-opus-4-6' => 'anthropic.claude-opus-4-6 [Flagship]',
                'meta.llama3-3-70b-instruct-v1:0' => 'meta.llama3-3-70b-instruct-v1:0 [Highlight]',
                'meta.llama3-1-405b-instruct-v1:0' => 'meta.llama3-1-405b-instruct-v1:0',
                'amazon.nova-pro-v1:0' => 'amazon.nova-pro-v1:0',
                'amazon.nova-lite-v1:0' => 'amazon.nova-lite-v1:0',
                'amazon.nova-micro-v1:0' => 'amazon.nova-micro-v1:0',
                'mistral.mistral-large-2402-v1:0' => 'mistral.mistral-large-2402-v1:0'
            ],
        ],
        'azure-openai' => [
            'label' => 'Azure OpenAI',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_azure-openai_key',
            'key_link'   => 'https://portal.azure.com',
            'models' => [
                'gpt-5' => 'gpt-5 [Flagship]',
                'gpt-4o' => 'gpt-4o [Highlight]',
                'gpt-4.1' => 'gpt-4.1 [Highlight]',
                'gpt-4.1-mini' => 'gpt-4.1-mini',
                'gpt-4.1-nano' => 'gpt-4.1-nano',
                'o3' => 'o3',
                'o4-mini' => 'o4-mini',
                'dall-e-3' => 'dall-e-3'
            ],
        ],
        'google-vertex-ai' => [
            'label' => 'Google Vertex AI',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_google-vertex-ai_key',
            'key_link'   => 'https://console.cloud.google.com/apis/credentials',
            'models' => [
                'gemini-3.1-pro' => 'gemini-3.1-pro [Flagship]',
                'gemini-3.1-flash' => 'gemini-3.1-flash [Flagship]',
                'gemini-2.5-pro' => 'gemini-2.5-pro [Highlight]',
                'imagen-4-generate' => 'imagen-4-generate',
                'meta/llama-3.3-70b-instruct-maas' => 'meta/llama-3.3-70b-instruct-maas'
            ],
        ],
        'replicate' => [
            'label' => 'Replicate',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_replicate_key',
            'key_link'   => 'https://replicate.com/account/api-tokens',
            'models' => [
                'meta/llama-3.3-70b-instruct' => 'meta/llama-3.3-70b-instruct',
                'black-forest-labs/flux-1.1-pro' => 'black-forest-labs/flux-1.1-pro [Highlight]',
                'black-forest-labs/flux-schnell' => 'black-forest-labs/flux-schnell',
                'stability-ai/sdxl' => 'stability-ai/sdxl',
                'mistralai/mixtral-8x7b-instruct-v0.1' => 'mistralai/mixtral-8x7b-instruct-v0.1'
            ],
        ],
        'deepinfra' => [
            'label' => 'DeepInfra',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_deepinfra_key',
            'key_link'   => 'https://deepinfra.com/dash/api_keys',
            'models' => [
                'meta-llama/Llama-4-Maverick-17B-128E-Instruct' => 'meta-llama/Llama-4-Maverick-17B-128E-Instruct [Flagship]',
                'meta-llama/Llama-3.3-70B-Instruct-Turbo' => 'meta-llama/Llama-3.3-70B-Instruct-Turbo [Highlight]',
                'deepseek-ai/DeepSeek-V3' => 'deepseek-ai/DeepSeek-V3',
                'Qwen/Qwen3-235B-A22B' => 'Qwen/Qwen3-235B-A22B',
                'mistralai/Mistral-7B-Instruct-v0.3' => 'mistralai/Mistral-7B-Instruct-v0.3'
            ],
        ],
        'aiml-api' => [
            'label' => 'AIML API',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_aiml-api_key',
            'key_link'   => 'https://aimlapi.com/app/keys',
            'models' => [
                'openai/gpt-5' => 'openai/gpt-5 [Flagship]',
                'anthropic/claude-opus-4-6' => 'anthropic/claude-opus-4-6 [Flagship]',
                'google/gemini-3.1-pro' => 'google/gemini-3.1-pro [Highlight]',
                'meta-llama/Llama-4-Maverick' => 'meta-llama/Llama-4-Maverick',
                'deepseek-ai/DeepSeek-R1' => 'deepseek-ai/DeepSeek-R1',
                'x-ai/grok-4' => 'x-ai/grok-4',
                '...200+ models' => '...200+ models'
            ],
        ],
        'naga-ai' => [
            'label' => 'Naga AI',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_naga-ai_key',
            'key_link'   => 'https://discord.com/invite/JxRBXBhabu',
            'models' => [
                'gpt-4o' => 'gpt-4o',
                'claude-3-5-sonnet' => 'claude-3-5-sonnet',
                'gemini-pro' => 'gemini-pro',
                'llama-3.3-70b' => 'llama-3.3-70b'
            ],
        ],
        'lemondata' => [
            'label' => 'LemonData',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_lemondata_key',
            'key_link'   => 'https://lemondata.cc',
            'models' => [
                'gpt-4o' => 'gpt-4o',
                'claude-sonnet-4' => 'claude-sonnet-4',
                'gemini-2.5-flash' => 'gemini-2.5-flash',
                'llama-3.3-70b' => 'llama-3.3-70b',
                '300+ models' => '300+ models'
            ],
        ],
        'yandex-yandexgpt' => [
            'label' => 'Yandex YandexGPT',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_yandex-yandexgpt_key',
            'key_link'   => 'https://console.yandex.cloud',
            'models' => [
                'yandexgpt-5-pro' => 'yandexgpt-5-pro [Flagship]',
                'yandexgpt-5-lite' => 'yandexgpt-5-lite [Highlight]',
                'yandexgpt-32k' => 'yandexgpt-32k',
                'yandex-gpt-latest' => 'yandex-gpt-latest'
            ],
        ],
        'maritaca-ai-sabi' => [
            'label' => 'MariTaca AI (Sabiá)',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_maritaca-ai-sabi_key',
            'key_link'   => 'https://plataforma.maritaca.ai/chaves-de-api',
            'models' => [
                'sabia-3' => 'sabia-3 [Flagship]',
                'sabia-2-small' => 'sabia-2-small [Highlight]',
                'maritalk' => 'maritalk'
            ],
        ],
        'aleph-alpha-pharia' => [
            'label' => 'Aleph Alpha (Pharia)',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_aleph-alpha-pharia_key',
            'key_link'   => 'https://app.aleph-alpha.com/profile',
            'models' => [
                'pharia-1-llm-7b-control' => 'pharia-1-llm-7b-control [Flagship]',
                'luminous-supreme-control' => 'luminous-supreme-control [Highlight]',
                'luminous-extended' => 'luminous-extended'
            ],
        ],
        'naver-hyperclova-x' => [
            'label' => 'Naver HyperCLOVA X',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_naver-hyperclova-x_key',
            'key_link'   => 'https://clova.ai',
            'models' => [
                'HCX-005' => 'HCX-005 [Flagship]',
                'HCX-003' => 'HCX-003 [Highlight]',
                'HCX-DASH-001' => 'HCX-DASH-001'
            ],
        ],
        'tii-falcon-uae' => [
            'label' => 'TII Falcon (UAE)',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_tii-falcon-uae_key',
            'key_link'   => 'https://huggingface.co/tiiuae',
            'models' => [
                'falcon-3-10b-instruct' => 'falcon-3-10b-instruct [Flagship FREE]',
                'falcon-3-7b-instruct' => 'falcon-3-7b-instruct [Flagship FREE]',
                'falcon-3-3b-instruct' => 'falcon-3-3b-instruct [Flagship FREE]',
                'falcon-3-1b-instruct' => 'falcon-3-1b-instruct [Flagship FREE]',
                'falcon-40b-instruct' => 'falcon-40b-instruct [Flagship FREE]'
            ],
        ],
        'iflytek-spark' => [
            'label' => 'iFlytek Spark',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_iflytek-spark_key',
            'key_link'   => 'https://console.xfyun.cn',
            'models' => [
                'spark-4.0-ultra' => 'spark-4.0-ultra [Flagship]',
                'spark-max' => 'spark-max [Highlight]',
                'spark-pro-128k' => 'spark-pro-128k [Flagship FREE]',
                'spark-lite' => 'spark-lite [Flagship FREE]'
            ],
        ],
        'friendliai' => [
            'label' => 'FriendliAI',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_friendliai_key',
            'key_link'   => 'https://suite.friendli.ai/user-settings/tokens',
            'models' => [
                'meta-llama-3.3-70b-instruct' => 'meta-llama-3.3-70b-instruct',
                'Qwen3-235B-A22B' => 'Qwen3-235B-A22B',
                'deepseek-v3-0324' => 'deepseek-v3-0324',
                'deepseek-r1' => 'deepseek-r1'
            ],
        ],
        'inception-labs-mercury' => [
            'label' => 'Inception Labs (Mercury)',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_inception-labs-mercury_key',
            'key_link'   => 'https://inceptionlabs.ai',
            'models' => [
                'mercury-coder-small-beta' => 'mercury-coder-small-beta [Flagship]',
                'mercury-diffusion-small' => 'mercury-diffusion-small [Highlight]'
            ],
        ],
        'ollama' => [
            'label' => 'Ollama',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_ollama_key',
            'key_link'   => 'https://ollama.com/download',
            'models' => [
                'llama3.3' => 'llama3.3 [Flagship FREE]',
                'llama3.2' => 'llama3.2 [Flagship Highlight FREE]',
                'llama3.2:1b' => 'llama3.2:1b [Flagship FREE]',
                'qwen3:8b' => 'qwen3:8b [Flagship FREE]',
                'qwen3:30b-a3b' => 'qwen3:30b-a3b [Flagship FREE]',
                'mistral' => 'mistral [Flagship FREE]',
                'gemma3:4b' => 'gemma3:4b [Flagship FREE]',
                'phi4' => 'phi4 [Flagship FREE]',
                'deepseek-r1:7b' => 'deepseek-r1:7b [Flagship FREE]',
                'mixtral:8x7b' => 'mixtral:8x7b [Flagship FREE]',
                'command-r' => 'command-r [Flagship FREE]',
                'smollm2' => 'smollm2 [Flagship FREE]',
                '...100+ more ↓ see below' => '...100+ more ↓ see below [Flagship FREE]'
            ],
        ],
        'lm-studio' => [
            'label' => 'LM Studio',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_lm-studio_key',
            'key_link'   => 'https://lmstudio.ai',
            'models' => [
                'Llama 3.3 70B GGUF' => 'Llama 3.3 70B GGUF [Flagship FREE]',
                'Mistral 7B GGUF' => 'Mistral 7B GGUF [Flagship FREE]',
                'Qwen 3 8B GGUF' => 'Qwen 3 8B GGUF [Flagship FREE]',
                'Phi-4 GGUF' => 'Phi-4 GGUF [Flagship FREE]',
                'DeepSeek-R1 GGUF' => 'DeepSeek-R1 GGUF [Flagship FREE]'
            ],
        ],
        'jan-ai' => [
            'label' => 'Jan AI',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_jan-ai_key',
            'key_link'   => 'https://jan.ai',
            'models' => [
                'Any GGUF model' => 'Any GGUF model [Flagship FREE]',
                'Llama 3.2' => 'Llama 3.2 [Flagship FREE]',
                'Mistral 7B' => 'Mistral 7B [Flagship FREE]',
                'Gemma 3' => 'Gemma 3 [Flagship FREE]'
            ],
        ],
        'gpt4all' => [
            'label' => 'GPT4All',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_gpt4all_key',
            'key_link'   => 'https://www.nomic.ai/gpt4all',
            'models' => [
                'Llama 3.2 3B' => 'Llama 3.2 3B [Flagship FREE]',
                'Phi-3 Mini' => 'Phi-3 Mini [Flagship Highlight FREE]',
                'Mistral 7B' => 'Mistral 7B [Flagship FREE]',
                'Orca Mini' => 'Orca Mini [Flagship FREE]',
                'GPT4All Falcon' => 'GPT4All Falcon [Flagship FREE]'
            ],
        ],
        'vllm-self-hosted' => [
            'label' => 'vLLM (Self-Hosted)',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_vllm-self-hosted_key',
            'key_link'   => 'https://github.com/vllm-project/vllm',
            'models' => [
                'meta-llama/Llama-3.3-70B' => 'meta-llama/Llama-3.3-70B',
                'mistralai/Mistral-7B-v0.1' => 'mistralai/Mistral-7B-v0.1',
                'Qwen/Qwen2.5-72B' => 'Qwen/Qwen2.5-72B'
            ],
        ],
        'puter-js' => [
            'label' => 'Puter.js',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_puter-js_key',
            'key_link'   => 'https://puter.com',
            'models' => [
                'gpt-4o' => 'gpt-4o [Flagship]',
                'claude-sonnet-4-6' => 'claude-sonnet-4-6 [Highlight]',
                'gemini-2.5-flash' => 'gemini-2.5-flash'
            ],
        ],
        'custom-base-url' => [
            'label' => 'Custom Base URL',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_custom-base-url_key',
            'key_link'   => '#',
            'models' => [
                'https://company-proxy.internal/v1' => 'https://company-proxy.internal/v1 [Highlight]',
                'http://localhost:8080/v1' => 'http://localhost:8080/v1',
                'https://api.your-server.com/v1' => 'https://api.your-server.com/v1'
            ],
        ],
        'jina-ai-reader' => [
            'label' => 'Jina AI Reader',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_jina-ai-reader_key',
            'key_link'   => 'https://jina.ai',
            'models' => [
                'r.jina.ai' => 'r.jina.ai [Flagship Highlight FREE]',
                'jina-embeddings-v3' => 'jina-embeddings-v3 [Flagship FREE]',
                'jina-reranker-v2-base-multilingual' => 'jina-reranker-v2-base-multilingual [Flagship FREE]'
            ],
        ],
        'tavily-ai-search' => [
            'label' => 'Tavily AI Search',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_tavily-ai-search_key',
            'key_link'   => 'https://app.tavily.com',
            'models' => [
                'search' => 'search [Flagship Highlight FREE]',
                'context' => 'context [Flagship FREE]',
                'extract (web reader)' => 'extract (web reader) [Flagship FREE]'
            ],
        ],
        'serper-dev' => [
            'label' => 'Serper.dev',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_serper-dev_key',
            'key_link'   => 'https://serper.dev',
            'models' => [
                'google search' => 'google search [Flagship Highlight FREE]',
                'news search' => 'news search [Flagship FREE]',
                'image search' => 'image search [Flagship FREE]',
                'places search' => 'places search [Flagship FREE]'
            ],
        ],
        'brave-search-api' => [
            'label' => 'Brave Search API',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_brave-search-api_key',
            'key_link'   => 'https://brave.com/search/api/',
            'models' => [
                'web search' => 'web search [Flagship Highlight FREE]',
                'news search' => 'news search [Flagship FREE]',
                'AI Summarizer' => 'AI Summarizer [Flagship FREE]'
            ],
        ],
        'youtube-data-api-v3' => [
            'label' => 'YouTube Data API v3',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_youtube-data-api-v3_key',
            'key_link'   => 'https://console.cloud.google.com/apis/library/youtube.googleapis.com',
            'models' => [
                'search.list' => 'search.list [Flagship Highlight FREE]',
                'videos.list' => 'videos.list [Flagship FREE]',
                'channels.list' => 'channels.list [Flagship FREE]'
            ],
        ],
        'unsplash-pexels-apis' => [
            'label' => 'Unsplash + Pexels APIs',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_unsplash-pexels-apis_key',
            'key_link'   => 'https://unsplash.com/developers',
            'models' => [
                'Unsplash: /search/photos' => 'Unsplash: /search/photos [Flagship Highlight FREE]',
                'Pexels: /v1/search' => 'Pexels: /v1/search [Flagship FREE]'
            ],
        ],
        'stability-ai' => [
            'label' => 'Stability AI',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_stability-ai_key',
            'key_link'   => 'https://platform.stability.ai/account/keys',
            'models' => [
                'stable-image-ultra' => 'stable-image-ultra [Flagship]',
                'stable-image-core' => 'stable-image-core [Highlight]',
                'sd3.5-large' => 'sd3.5-large',
                'sd3.5-large-turbo' => 'sd3.5-large-turbo',
                'sd3.5-medium' => 'sd3.5-medium'
            ],
        ],
        'fal-ai' => [
            'label' => 'fal.ai',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_fal-ai_key',
            'key_link'   => 'https://fal.ai/dashboard/keys',
            'models' => [
                'fal-ai/flux-pro/v1.1-ultra' => 'fal-ai/flux-pro/v1.1-ultra [Flagship]',
                'fal-ai/flux/schnell' => 'fal-ai/flux/schnell [Highlight]',
                'fal-ai/flux-realism' => 'fal-ai/flux-realism',
                'fal-ai/ideogram/v3' => 'fal-ai/ideogram/v3',
                'fal-ai/fast-sdxl' => 'fal-ai/fast-sdxl'
            ],
        ],
        'elevenlabs-tts' => [
            'label' => 'ElevenLabs (TTS)',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_elevenlabs-tts_key',
            'key_link'   => 'https://elevenlabs.io/app/settings/api-keys',
            'models' => [
                'eleven_multilingual_v2' => 'eleven_multilingual_v2 [Flagship FREE]',
                'eleven_turbo_v2_5' => 'eleven_turbo_v2_5 [Highlight]',
                'eleven_flash_v2_5' => 'eleven_flash_v2_5',
                'eleven_monolingual_v1' => 'eleven_monolingual_v1'
            ],
        ],
        'voyage-ai-embeddings' => [
            'label' => 'Voyage AI (Embeddings)',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_voyage-ai-embeddings_key',
            'key_link'   => 'https://dash.voyageai.com/api-keys',
            'models' => [
                'voyage-3' => 'voyage-3 [Flagship FREE]',
                'voyage-3-lite' => 'voyage-3-lite [Flagship Highlight FREE]',
                'voyage-3-large' => 'voyage-3-large',
                'voyage-code-3' => 'voyage-code-3',
                'voyage-multimodal-3' => 'voyage-multimodal-3'
            ],
        ],
        'chutes-ai' => [
            'label' => 'Chutes AI',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_chutes-ai_key',
            'key_link'   => 'https://chutes.ai',
            'models' => [
                'deepseek-ai/DeepSeek-R1-0528' => 'deepseek-ai/DeepSeek-R1-0528 [Flagship FREE]',
                'Qwen/Qwen3-235B-A22B' => 'Qwen/Qwen3-235B-A22B [Flagship FREE]',
                'meta-llama/Llama-3.3-70B' => 'meta-llama/Llama-3.3-70B [Flagship FREE]'
            ],
        ],
        'lepton-ai' => [
            'label' => 'Lepton AI',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_lepton-ai_key',
            'key_link'   => 'https://dashboard.lepton.ai/credentials/api-tokens',
            'models' => [
                'llama3-3-70b' => 'llama3-3-70b',
                'llama3-1-405b' => 'llama3-1-405b',
                'qwen2-5-72b' => 'qwen2-5-72b',
                'mistral-7b' => 'mistral-7b'
            ],
        ],
        'atoma-network' => [
            'label' => 'Atoma Network',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_atoma-network_key',
            'key_link'   => 'https://cloud.atoma.network',
            'models' => [
                'meta-llama/llama-3.3-70b-instruct' => 'meta-llama/llama-3.3-70b-instruct',
                'deepseek-ai/deepseek-r1' => 'deepseek-ai/deepseek-r1'
            ],
        ],
        'meta-llama-api-direct' => [
            'label' => 'Meta Llama API (Direct)',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_meta-llama-api-direct_key',
            'key_link'   => 'https://llama.com',
            'models' => [
                'Llama-4-Maverick-17B-128E-Instruct-FP8' => 'Llama-4-Maverick-17B-128E-Instruct-FP8 [Flagship]',
                'Llama-4-Scout-17B-16E-Instruct' => 'Llama-4-Scout-17B-16E-Instruct [Highlight]',
                'Llama-3.3-70B-Instruct' => 'Llama-3.3-70B-Instruct'
            ],
        ],
        'ibm-watsonx-granite' => [
            'label' => 'IBM Watsonx (Granite)',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_ibm-watsonx-granite_key',
            'key_link'   => 'https://cloud.ibm.com/iam/apikeys',
            'models' => [
                'granite-3-3-8b-instruct' => 'granite-3-3-8b-instruct [Flagship Highlight FREE]',
                'granite-3-3-2b-instruct' => 'granite-3-3-2b-instruct [Flagship FREE]',
                'llama-3-1-70b-instruct' => 'llama-3-1-70b-instruct'
            ],
        ],
        'mixedbread-embeddings' => [
            'label' => 'Mixedbread (Embeddings)',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_mixedbread-embeddings_key',
            'key_link'   => 'https://www.mixedbread.ai/api-reference#authentication',
            'models' => [
                'mxbai-embed-large-v1' => 'mxbai-embed-large-v1 [Flagship FREE]',
                'mxbai-rerank-large-v1' => 'mxbai-rerank-large-v1 [Flagship Highlight FREE]'
            ],
        ],
        'baseten' => [
            'label' => 'Baseten',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_baseten_key',
            'key_link'   => 'https://www.baseten.co/dashboard/keys',
            'models' => [
                'Llama 3.3 70B' => 'Llama 3.3 70B',
                'Mistral 7B' => 'Mistral 7B',
                'Custom Fine-tuned Models' => 'Custom Fine-tuned Models'
            ],
        ],
        'sber-gigachat' => [
            'label' => 'Sber GigaChat',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_sber-gigachat_key',
            'key_link'   => 'https://developers.sber.ru/studio',
            'models' => [
                'GigaChat-2-Max' => 'GigaChat-2-Max [Flagship]',
                'GigaChat-2-Pro' => 'GigaChat-2-Pro [Flagship Highlight FREE]',
                'GigaChat-2' => 'GigaChat-2 [Flagship FREE]'
            ],
        ],
        'inference-net' => [
            'label' => 'Inference.net',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_inference-net_key',
            'key_link'   => 'https://inference.net/dashboard/api-keys',
            'models' => [
                'llama-3.3-70b' => 'llama-3.3-70b',
                'qwen2.5-72b' => 'qwen2.5-72b',
                'deepseek-r1-distill-qwen-32b' => 'deepseek-r1-distill-qwen-32b'
            ],
        ],
        'siliconflow' => [
            'label' => 'SiliconFlow',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_siliconflow_key',
            'key_link'   => 'https://cloud.siliconflow.cn/account/ak',
            'models' => [
                'Qwen/Qwen3-235B-A22B' => 'Qwen/Qwen3-235B-A22B [Flagship FREE]',
                'deepseek-ai/DeepSeek-V3' => 'deepseek-ai/DeepSeek-V3 [Flagship FREE]',
                'meta-llama/Meta-Llama-3.1-8B-Instruct' => 'meta-llama/Meta-Llama-3.1-8B-Instruct [Flagship FREE]'
            ],
        ],
        'nebius-ai' => [
            'label' => 'Nebius AI',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_nebius-ai_key',
            'key_link'   => 'https://studio.nebius.com/settings/api-keys',
            'models' => [
                'meta-llama/Llama-3.3-70B-Instruct' => 'meta-llama/Llama-3.3-70B-Instruct',
                'deepseek-ai/DeepSeek-V3' => 'deepseek-ai/DeepSeek-V3',
                'Qwen/Qwen3-235B-A22B' => 'Qwen/Qwen3-235B-A22B'
            ],
        ],
        'octoai' => [
            'label' => 'OctoAI',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_octoai_key',
            'key_link'   => 'https://octoai.cloud/settings',
            'models' => [
                'meta-llama-3.3-70b-instruct' => 'meta-llama-3.3-70b-instruct',
                'mixtral-8x22b-instruct' => 'mixtral-8x22b-instruct',
                'deepseek-r1-distill-llama-70b' => 'deepseek-r1-distill-llama-70b'
            ],
        ],
        'groq-batch-api' => [
            'label' => 'Groq Batch API',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_groq-batch-api_key',
            'key_link'   => 'https://console.groq.com/keys',
            'models' => [
                'llama-3.3-70b-versatile' => 'llama-3.3-70b-versatile [Flagship FREE]',
                'llama-3.1-8b-instant' => 'llama-3.1-8b-instant [Flagship FREE]'
            ],
        ],
        'aws-sagemaker' => [
            'label' => 'AWS SageMaker',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_aws-sagemaker_key',
            'key_link'   => 'https://aws.amazon.com/sagemaker/',
            'models' => [
                'meta-llama-3-70b-instruct' => 'meta-llama-3-70b-instruct',
                'mistral-7b-instruct' => 'mistral-7b-instruct',
                'falcon-40b-instruct' => 'falcon-40b-instruct'
            ],
        ],
        'oracle-genai' => [
            'label' => 'Oracle GenAI',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_oracle-genai_key',
            'key_link'   => 'https://cloud.oracle.com',
            'models' => [
                'meta.llama-3.3-70b-instruct' => 'meta.llama-3.3-70b-instruct',
                'cohere.command-r-plus' => 'cohere.command-r-plus'
            ],
        ],
        'clarifai' => [
            'label' => 'Clarifai',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_clarifai_key',
            'key_link'   => 'https://clarifai.com/settings/security',
            'models' => [
                'gpt-4o' => 'gpt-4o',
                'claude-3-5-sonnet' => 'claude-3-5-sonnet',
                'llama-3-70b-instruct' => 'llama-3-70b-instruct'
            ],
        ],
        'cortecs-ai' => [
            'label' => 'Cortecs AI',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_cortecs-ai_key',
            'key_link'   => 'https://console.cortecs.ai',
            'models' => [
                'kimi-k2-instruct' => 'kimi-k2-instruct',
                'llama-3.3-70b' => 'llama-3.3-70b'
            ],
        ],
        'mistral-lechat-api' => [
            'label' => 'Mistral (LeChat API)',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_mistral-lechat-api_key',
            'key_link'   => 'https://console.mistral.ai/api-keys',
            'models' => [
                'codestral-latest' => 'codestral-latest [Flagship]',
                'codestral-2501' => 'codestral-2501'
            ],
        ],
        'openai-tts-whisper' => [
            'label' => 'OpenAI TTS / Whisper',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_openai-tts-whisper_key',
            'key_link'   => 'https://platform.openai.com/api-keys',
            'models' => [
                'gpt-4o-mini-tts' => 'gpt-4o-mini-tts [Flagship]',
                'tts-1-hd' => 'tts-1-hd [Highlight]',
                'tts-1' => 'tts-1',
                'whisper-1' => 'whisper-1',
                'gpt-4o-transcribe' => 'gpt-4o-transcribe'
            ],
        ],
        'groq-vision-models' => [
            'label' => 'Groq Vision Models',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_groq-vision-models_key',
            'key_link'   => 'https://console.groq.com/keys',
            'models' => [
                'llama-3.2-90b-vision-preview' => 'llama-3.2-90b-vision-preview [Flagship Highlight FREE]',
                'llama-3.2-11b-vision-preview' => 'llama-3.2-11b-vision-preview [Flagship FREE]'
            ],
        ],
        'you-com-search' => [
            'label' => 'You.com Search',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_you-com-search_key',
            'key_link'   => 'https://api.you.com',
            'models' => [
                'web search' => 'web search [Flagship FREE]',
                'news search' => 'news search [Flagship FREE]',
                'research AI' => 'research AI'
            ],
        ],
        'groq-batch-mode' => [
            'label' => 'Groq (Batch Mode)',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_groq-batch-mode_key',
            'key_link'   => 'https://console.groq.com/keys',
            'models' => [
                'All Groq models' => 'All Groq models [Flagship FREE]'
            ],
        ],
        'openai-batch-api' => [
            'label' => 'OpenAI Batch API',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_openai-batch-api_key',
            'key_link'   => 'https://platform.openai.com/api-keys',
            'models' => [
                'gpt-4o' => 'gpt-4o [Flagship]',
                'gpt-4o-mini' => 'gpt-4o-mini [Highlight]',
                'gpt-4.1' => 'gpt-4.1'
            ],
        ],
        'anthropic-batch-api' => [
            'label' => 'Anthropic Batch API',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_anthropic-batch-api_key',
            'key_link'   => 'https://console.anthropic.com/keys',
            'models' => [
                'claude-sonnet-4-6' => 'claude-sonnet-4-6 [Flagship]',
                'claude-haiku-4-5' => 'claude-haiku-4-5 [Highlight]'
            ],
        ],
        'google-batch-gemini' => [
            'label' => 'Google Batch (Gemini)',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_google-batch-gemini_key',
            'key_link'   => 'https://aistudio.google.com/app/apikey',
            'models' => [
                'gemini-2.5-flash' => 'gemini-2.5-flash [Flagship]',
                'gemini-2.5-pro' => 'gemini-2.5-pro [Highlight]'
            ],
        ],
        '302-ai' => [
            'label' => '302.AI',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_302-ai_key',
            'key_link'   => 'https://302.ai',
            'models' => [
                'gpt-5' => 'gpt-5 [Flagship]',
                'claude-opus-4-6' => 'claude-opus-4-6',
                'gemini-2.5-pro' => 'gemini-2.5-pro',
                'llama-4-maverick' => 'llama-4-maverick'
            ],
        ],
        'mistral-free-models' => [
            'label' => 'Mistral (Free Models)',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_mistral-free-models_key',
            'key_link'   => '#',
            'models' => [
                'mistral' => 'mistral [Flagship FREE]',
                'mistral-nemo' => 'mistral-nemo [Flagship FREE]',
                'mistral-small3.2' => 'mistral-small3.2 [Flagship FREE]'
            ],
        ],
        'openai-embeddings' => [
            'label' => 'OpenAI Embeddings',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_openai-embeddings_key',
            'key_link'   => 'https://platform.openai.com/api-keys',
            'models' => [
                'text-embedding-3-large' => 'text-embedding-3-large [Flagship]',
                'text-embedding-3-small' => 'text-embedding-3-small [Highlight]',
                'text-embedding-ada-002' => 'text-embedding-ada-002'
            ],
        ],
        'gemini-embeddings' => [
            'label' => 'Gemini Embeddings',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_gemini-embeddings_key',
            'key_link'   => 'https://aistudio.google.com/app/apikey',
            'models' => [
                'gemini-embedding-001' => 'gemini-embedding-001 [Flagship FREE]',
                'text-embedding-004' => 'text-embedding-004 [Flagship FREE]'
            ],
        ],
        'pixabay-api' => [
            'label' => 'Pixabay API',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_pixabay-api_key',
            'key_link'   => 'https://pixabay.com/api/docs/',
            'models' => [
                'image search' => 'image search [Flagship FREE]',
                'video search' => 'video search [Flagship FREE]'
            ],
        ],
        'ideogram-ai' => [
            'label' => 'Ideogram AI',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_ideogram-ai_key',
            'key_link'   => 'https://developer.ideogram.ai',
            'models' => [
                'V_3' => 'V_3 [Flagship]',
                'V_2' => 'V_2 [Highlight]',
                'V_2_TURBO' => 'V_2_TURBO'
            ],
        ],
        'flux-api-black-forest-labs' => [
            'label' => 'Flux API (Black Forest Labs)',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_flux-api-black-forest-labs_key',
            'key_link'   => 'https://api.bfl.ml',
            'models' => [
                'flux-pro-1.1-ultra' => 'flux-pro-1.1-ultra [Flagship]',
                'flux-pro-1.1' => 'flux-pro-1.1 [Highlight]',
                'flux-pro' => 'flux-pro',
                'flux-dev' => 'flux-dev',
                'flux-schnell' => 'flux-schnell'
            ],
        ],
        'gemini-flash-free-ollama' => [
            'label' => 'Gemini (Flash Free) + Ollama',
            'key_placeholder' => 'sk-...',
            'key_option' => 'rudnexx_gemini-flash-free-ollama_key',
            'key_link'   => 'https://aistudio.google.com/app/apikey',
            'models' => [
                'gemini-2.5-flash' => 'gemini-2.5-flash [Flagship FREE]',
                'llama3.2' => 'llama3.2 [Flagship FREE]',
                'gemini-2.5-flash-lite' => 'gemini-2.5-flash-lite [Flagship FREE]',
                'llama3.2:1b' => 'llama3.2:1b [Flagship FREE]'
            ],
        ]
    ];
}
