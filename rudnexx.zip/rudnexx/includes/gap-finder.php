<?php
if (!defined('ABSPATH')) { exit; }

// Gap Finder submenu page
add_action('admin_menu', 'rudnexx_gap_finder_menu');
function rudnexx_gap_finder_menu() {
    add_submenu_page('rudnexx-settings', 'Keyword Gap Finder', '🔍 Keyword Gaps', 'manage_options', 'rudnexx-gap-finder', 'rudnexx_gap_finder_page_html');
}

// AJAX handler: SERVER-SIDE call to the Next.js gap-finder API (avoids CORS)
add_action('wp_ajax_rudnexx_find_gaps', 'rudnexx_ajax_find_gaps');
function rudnexx_ajax_find_gaps() {
    check_ajax_referer('rudnexx_gap_nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Unauthorized');
    }

    $license_key = get_option('rudnexx_license_key', '');
    $domain      = $_SERVER['SERVER_NAME'];
    $provider    = get_option('rudnexx_active_provider', 'openai');
    $api_key     = get_option('rudnexx_' . $provider . '_key', '');
    $model       = get_option('rudnexx_' . $provider . '_model', '');

    // Gather site profile
    $posts       = get_posts(['numberposts' => 50, 'post_status' => 'publish', 'post_type' => 'post']);
    $titles      = array_map(function($p){ return $p->post_title; }, $posts);
    $tags_raw    = get_tags(['hide_empty' => true, 'number' => 40]);
    $tags        = array_map(function($t){ return $t->name; }, $tags_raw);
    $cats_raw    = get_categories(['hide_empty' => true]);
    $cats        = array_map(function($c){ return $c->name; }, $cats_raw);

    $request_body = [
        'licenseKey'     => $license_key,
        'domain'         => $domain,
        'provider'       => $provider,
        'apiKey'         => $api_key,
        'model'          => $model,
        'existingTitles' => $titles,
        'tags'           => $tags,
        'categories'     => $cats,
    ];

    // Server-side call — no CORS issues
    $response = wp_remote_post(RUDNEXX_API_URL . '/gap-finder', [
        'timeout' => 60,
        'headers' => ['Content-Type' => 'application/json'],
        'body'    => wp_json_encode($request_body),
    ]);

    if (is_wp_error($response)) {
        wp_send_json_error('API Connection Error: ' . $response->get_error_message());
    }

    $status = wp_remote_retrieve_response_code($response);
    $body   = json_decode(wp_remote_retrieve_body($response), true);

    if ($status !== 200 || empty($body['success'])) {
        $err = $body['error'] ?? 'Unknown error from API';
        wp_send_json_error($err);
    }

    wp_send_json_success($body['suggestions']);
}

// AJAX handler: add a gap topic to the bulk keyword queue
add_action('wp_ajax_rudnexx_add_to_queue', 'rudnexx_ajax_add_to_queue');
function rudnexx_ajax_add_to_queue() {
    check_ajax_referer('rudnexx_queue_nonce');
    if (!current_user_can('manage_options')) {
        wp_send_json_error('Unauthorized');
    }
    $topic = sanitize_text_field($_POST['topic'] ?? '');
    if (empty($topic)) wp_send_json_error('Empty topic');

    $existing = get_option('rudnexx_bulk_keywords', '');
    $lines = array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', $existing)));
    if (!in_array($topic, $lines)) {
        $lines[] = $topic;
        update_option('rudnexx_bulk_keywords', implode("\n", $lines));
    }
    wp_send_json_success('Added');
}

function rudnexx_gap_finder_page_html() {
    if (!current_user_can('manage_options')) return;

    $posts    = get_posts(['numberposts' => 50, 'post_status' => 'publish', 'post_type' => 'post']);
    $tags_raw = get_tags(['hide_empty' => true, 'number' => 40]);
    $cats_raw = get_categories(['hide_empty' => true]);
    
    $queued_raw = get_option('rudnexx_bulk_keywords', '');
    $queued_arr = array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', $queued_raw)));
    $queued_json = json_encode(array_values($queued_arr));
    ?>
    <style>
        .rnx-gap-wrap{max-width:900px;margin:20px auto;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif}
        .rnx-gap-card{background:#fff;border:1px solid #e0e0e0;border-radius:10px;padding:24px 28px;margin-bottom:20px;box-shadow:0 1px 4px rgba(0,0,0,.06)}
        .rnx-gap-card h2{margin:0 0 12px;font-size:16px;font-weight:700;color:#1a1a2e}
        .rnx-gap-item{display:flex;align-items:flex-start;gap:14px;padding:12px 0;border-bottom:1px solid #f0f0f0}
        .rnx-gap-item:last-child{border-bottom:none}
        .rnx-priority{padding:3px 9px;border-radius:12px;font-size:11px;font-weight:700;white-space:nowrap}
        .rnx-priority.high{background:#fef2f2;color:#dc2626}
        .rnx-priority.medium{background:#fffbeb;color:#d97706}
        .rnx-priority.low{background:#f0fdf4;color:#16a34a}
        .rnx-gap-topic{font-size:14px;font-weight:600;color:#1a1a2e;margin-bottom:3px}
        .rnx-gap-reason{font-size:13px;color:#6b7280}
        .rnx-add-btn{margin-left:auto;padding:5px 14px;background:#6c63ff;color:#fff;border:none;border-radius:6px;cursor:pointer;font-size:12px;font-weight:600;white-space:nowrap}
        .rnx-add-btn:hover{background:#5a52d5}
        .rnx-add-btn.added{background:#22c55e;cursor:default}
        #rnx-gap-results{margin-top:24px}
        #rnx-gap-status{padding:12px 16px;border-radius:8px;font-size:13px;margin-bottom:16px;display:none}
    </style>

    <div class="rnx-gap-wrap">
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:24px">
            <span class="dashicons dashicons-search" style="font-size:30px;color:#6c63ff"></span>
            <div>
                <h1 style="margin:0;font-size:22px;color:#1a1a2e">🔍 SEO Content Gap Finder</h1>
                <p style="margin:0;color:#888;font-size:13px">Analyze your site and discover high-value missing topics to rank for.</p>
            </div>
        </div>

        <div class="rnx-gap-card">
            <h2>Site Profile</h2>
            <p style="font-size:13px;color:#555;margin:0 0 16px">Currently analyzing <strong><?php echo count($posts); ?> published posts</strong>, <strong><?php echo count($tags_raw); ?> tags</strong>, and <strong><?php echo count($cats_raw); ?> categories</strong>.</p>
            <button id="rnx-gap-btn" class="button button-primary" style="background:#6c63ff;border-color:#6c63ff;font-size:14px;height:38px;padding:0 20px">
                ⚡ Find Missing Topics
            </button>
            <div id="rnx-gap-status"></div>
        </div>

        <div id="rnx-gap-results" style="display:none">
            <div class="rnx-gap-card">
                <h2>💡 Keyword Opportunities</h2>
                <div style="font-size:13px;color:#555;margin:-4px 0 16px;background:#f8fafc;padding:12px;border-radius:6px;border:1px solid #e2e8f0;">
                    <strong>Understanding Priorities:</strong>
                    <ul style="margin:6px 0 0 16px;padding:0;">
                        <li><span class="rnx-priority high" style="padding:1px 5px;font-size:10px;margin-right:6px">HIGH</span> Fast ranking potential. Low competition + high relevance.</li>
                        <li><span class="rnx-priority medium" style="padding:1px 5px;font-size:10px;margin-right:6px">MEDIUM</span> Good topics to cover for topical authority. Average competition.</li>
                        <li><span class="rnx-priority low" style="padding:1px 5px;font-size:10px;margin-right:6px">LOW</span> Highly competitive or niche topics. Harder to rank quickly.</li>
                    </ul>
                </div>
                <p style="font-size:13px;color:#555;margin:16px 0">Click <strong>"➕ Add to Queue"</strong> to send a topic to your bulk keyword scheduler. 
                <br><small style="color:#888;">(Topics are safely saved to your queue format: one keyword per line, separated automatically. The auto-scheduler will process them seamlessly.)</small></p>
                <div id="rnx-gap-list"></div>
            </div>
        </div>
    </div>

    <script>
    (function() {
        var btn       = document.getElementById('rnx-gap-btn');
        var resultsEl = document.getElementById('rnx-gap-results');
        var listEl    = document.getElementById('rnx-gap-list');
        var statusEl  = document.getElementById('rnx-gap-status');

        function showStatus(msg, isError) {
            statusEl.style.display = 'block';
            statusEl.style.background = isError ? '#fef2f2' : '#f0fdf4';
            statusEl.style.color      = isError ? '#dc2626' : '#16a34a';
            statusEl.textContent = msg;
        }

        btn.addEventListener('click', function() {
            btn.textContent = '⏳ Researching...';
            btn.disabled = true;
            statusEl.style.display = 'none';
            var existingQueue = <?php echo $queued_json; ?>;

            // Use wp-ajax.php server-side — no CORS!
            var formData = new FormData();
            formData.append('action', 'rudnexx_find_gaps');
            formData.append('_ajax_nonce', '<?php echo wp_create_nonce('rudnexx_gap_nonce'); ?>');

            fetch('<?php echo esc_js(admin_url('admin-ajax.php')); ?>', {
                method: 'POST',
                body: formData
            })
            .then(function(r){ return r.json(); })
            .then(function(res) {
                btn.textContent = '⚡ Find Missing Topics';
                btn.disabled = false;

                if (!res.success || !res.data || !res.data.length) {
                    showStatus('❌ ' + (res.data || 'Could not generate suggestions. Check your license and AI key.'), true);
                    return;
                }

                listEl.innerHTML = '';
                res.data.forEach(function(item) {
                    var priority = (item.priority || 'medium').toLowerCase();
                    var isQueued = existingQueue.includes(item.topic);
                    var btnHtml = isQueued 
                        ? '<button class="rnx-add-btn added" disabled>✅ Added</button>'
                        : '<button class="rnx-add-btn" data-topic="' + item.topic.replace(/"/g,'&quot;') + '">➕ Add to Queue</button>';
                    
                    var div = document.createElement('div');
                    div.className = 'rnx-gap-item';
                    div.innerHTML =
                        '<span class="rnx-priority ' + priority + '">' + priority.toUpperCase() + '</span>' +
                        '<div style="flex:1"><div class="rnx-gap-topic">' + item.topic + '</div>' +
                        '<div class="rnx-gap-reason">' + item.reason + '</div></div>' + btnHtml;
                    listEl.appendChild(div);
                });

                // Add-to-queue AJAX
                listEl.querySelectorAll('.rnx-add-btn:not(.added)').forEach(function(addBtn) {
                    addBtn.addEventListener('click', function() {
                        var topic = this.getAttribute('data-topic');
                        var self = this;
                        var fd2 = new FormData();
                        fd2.append('action', 'rudnexx_add_to_queue');
                        fd2.append('topic', topic);
                        fd2.append('_ajax_nonce', '<?php echo wp_create_nonce('rudnexx_queue_nonce'); ?>');
                        fetch('<?php echo esc_js(admin_url('admin-ajax.php')); ?>', { method: 'POST', body: fd2 })
                        .then(function(r){ return r.json(); })
                        .then(function(r2) {
                            if (r2.success) {
                                self.textContent = '✅ Added!';
                                self.classList.add('added');
                                self.disabled = true;
                            }
                        });
                    });
                });

                resultsEl.style.display = 'block';
            })
            .catch(function(err) {
                btn.textContent = '⚡ Find Missing Topics';
                btn.disabled = false;
                showStatus('❌ Error: ' + err.message, true);
            });
        });
    })();
    </script>
    <?php
}
