<?php
if (!defined('ABSPATH')) { exit; }

// Analytics submenu page
add_action('admin_menu', 'rudnexx_analytics_menu');
function rudnexx_analytics_menu() {
    add_submenu_page('rudnexx-settings', 'AI Analytics', '📊 Analytics', 'manage_options', 'rudnexx-analytics', 'rudnexx_analytics_page_html');
}

function rudnexx_analytics_page_html() {
    if (!current_user_can('manage_options')) return;

    // 1. Total Posts Generated All Time
    $total_args = [
        'post_type'      => 'post',
        'post_status'    => ['publish', 'draft'],
        'posts_per_page' => -1,
        'fields'         => 'ids',
        'meta_query'     => [
            [
                'key'     => 'rudnexx_generated',
                'value'   => 1,
                'compare' => '='
            ]
        ]
    ];
    $total_query = new WP_Query($total_args);
    $total_posts = $total_query->found_posts;

    // 2. Posts Generated This Month
    $month_args = $total_args;
    $month_args['date_query'] = [
        [
            'year'  => date('Y'),
            'month' => date('m'),
        ],
    ];
    $month_query = new WP_Query($month_args);
    $posts_this_month = $month_query->found_posts;

    // 3. Provider Data (Direct SQL for grouped count)
    global $wpdb;
    $provider_counts = $wpdb->get_results("
        SELECT meta_value as provider, COUNT(post_id) as count 
        FROM {$wpdb->postmeta} 
        WHERE meta_key = 'rudnexx_ai_provider'
        GROUP BY meta_value
        ORDER BY count DESC
    ");

    $active_provider = get_option('rudnexx_active_provider', 'openai');
    $active_model    = get_option('rudnexx_' . $active_provider . '_model', '');
    require_once plugin_dir_path(__FILE__) . 'providers-config.php';
    $provider_names = rudnexx_get_providers();
    $provider_label = isset($provider_names[$active_provider]['label']) ? $provider_names[$active_provider]['label'] : ucfirst($active_provider);
    $config_display = $provider_label . ($active_model ? ' / ' . $active_model : '');
    ?>
    <style>
        .rnx-dashboard{max-width:1000px;margin:24px auto;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif}
        .rnx-hero{background:linear-gradient(135deg, #6c63ff, #8b5cf6);border-radius:12px;padding:30px 40px;color:#fff;display:flex;align-items:center;justify-content:space-between;box-shadow:0 10px 25px -5px rgba(108,99,255,.4);margin-bottom:30px}
        .rnx-hero-title{font-size:28px;font-weight:700;margin:0 0 8px;display:flex;align-items:center;gap:12px}
        .rnx-hero-sub{font-size:15px;opacity:0.9;margin:0;max-width:500px;line-height:1.5}
        .rnx-hero-stat{text-align:right}
        .rnx-hero-stat-num{font-size:42px;font-weight:800;line-height:1;margin-bottom:5px;text-shadow:0 2px 4px rgba(0,0,0,.1)}
        .rnx-hero-stat-label{font-size:13px;text-transform:uppercase;letter-spacing:1px;opacity:0.8;font-weight:600}
        
        .rnx-grid{display:grid;grid-template-columns:repeat(auto-fit, minmax(300px, 1fr));gap:20px;margin-bottom:30px}
        .rnx-card{background:#fff;border-radius:10px;padding:24px;border:1px solid #e2e8f0;box-shadow:0 2px 4px rgba(0,0,0,.02)}
        .rnx-card-title{font-size:16px;font-weight:700;color:#1e293b;margin:0 0 20px;display:flex;align-items:center;gap:8px}
        
        .rnx-stat-row{display:flex;align-items:center;justify-content:space-between;padding:12px 0;border-bottom:1px solid #f1f5f9}
        .rnx-stat-row:last-child{border-bottom:none;padding-bottom:0}
        .rnx-stat-label{font-size:14px;color:#475569;font-weight:500}
        .rnx-stat-val{font-size:16px;font-weight:700;color:#0f172a}
        
        .rnx-provider-list{list-style:none;padding:0;margin:0}
        .rnx-provider-item{display:flex;align-items:center;margin-bottom:14px}
        .rnx-provider-name{font-size:14px;color:#334155;flex:1;font-weight:500}
        .rnx-provider-bar-wrap{flex:2;background:#f1f5f9;height:8px;border-radius:4px;overflow:hidden;margin:0 15px}
        .rnx-provider-bar{height:100%;background:#8b5cf6;border-radius:4px}
        .rnx-provider-count{font-size:13px;font-weight:700;color:#64748b;width:30px;text-align:right}
        
        .rnx-status-badge{display:inline-flex;align-items:center;padding:4px 10px;background:#ecfdf5;color:#059669;border-radius:20px;font-size:12px;font-weight:700;margin-top:15px;border:1px solid #a7f3d0}
        .rnx-status-badge .dashicons{font-size:14px;width:14px;height:14px;margin-right:4px}
    </style>

    <div class="rnx-dashboard">
        
        <div class="rnx-hero">
            <div>
                <h1 class="rnx-hero-title"><span class="dashicons dashicons-chart-area" style="font-size:32px;width:32px;height:32px"></span> Auto-Blogger Analytics</h1>
                <p class="rnx-hero-sub">Track your content growth and AI provider distribution over time.</p>
                <?php if (wp_next_scheduled('rudnexx_auto_blog_cron')): ?>
                    <div class="rnx-status-badge"><span class="dashicons dashicons-yes-alt"></span> Scheduler is Active</div>
                <?php else: ?>
                    <div class="rnx-status-badge" style="background:#fef2f2;color:#dc2626;border-color:#fecaca"><span class="dashicons dashicons-warning"></span> Scheduler is Paused</div>
                <?php endif; ?>
            </div>
            <div class="rnx-hero-stat">
                <div class="rnx-hero-stat-num"><?php echo esc_html($total_posts); ?></div>
                <div class="rnx-hero-stat-label">Total Articles Generated</div>
            </div>
        </div>

        <div class="rnx-grid">
            
            <div class="rnx-card">
                <h2 class="rnx-card-title"><span class="dashicons dashicons-calendar-alt"></span> Content Velocity</h2>
                <div class="rnx-stat-row">
                    <span class="rnx-stat-label">Articles Generated This Month</span>
                    <span class="rnx-stat-val" style="color:#6c63ff"><?php echo esc_html($posts_this_month); ?></span>
                </div>
                <div class="rnx-stat-row">
                    <span class="rnx-stat-label">Total Articles All-Time</span>
                    <span class="rnx-stat-val"><?php echo esc_html($total_posts); ?></span>
                </div>
                <div class="rnx-stat-row">
                    <span class="rnx-stat-label">Keywords Queued</span>
                    <span class="rnx-stat-val">
                        <?php 
                        $queued = get_option('rudnexx_bulk_keywords', '');
                        $count = count(array_filter(array_map('trim', preg_split('/\r\n|\r|\n/', $queued))));
                        echo esc_html($count);
                        ?>
                    </span>
                </div>
                <div class="rnx-stat-row">
                    <span class="rnx-stat-label">Current Configuration</span>
                    <span class="rnx-stat-val" style="font-size:12px;background:#f8fafc;padding:3px 8px;border-radius:4px;border:1px solid #e2e8f0"><?php echo esc_html($config_display); ?></span>
                </div>
            </div>

            <div class="rnx-card">
                <h2 class="rnx-card-title"><span class="dashicons dashicons-share-alt2"></span> AI Provider Distribution</h2>
                <?php if (empty($provider_counts)): ?>
                    <p style="color:#64748b;font-size:14px;margin:30px 0;text-align:center">No articles generated yet. Your AI usage breakdown will appear here.</p>
                <?php else: ?>
                    <ul class="rnx-provider-list">
                        <?php 
                        $max_count = max(array_column($provider_counts, 'count'));
                        foreach ($provider_counts as $p): 
                            $percentage = ($p->count / $max_count) * 100;
                            $name = isset($provider_names[$p->provider]) ? $provider_names[$p->provider]['label'] : ucfirst(esc_html($p->provider));
                        ?>
                            <li class="rnx-provider-item">
                                <span class="rnx-provider-name"><?php echo esc_html($name); ?></span>
                                <div class="rnx-provider-bar-wrap">
                                    <div class="rnx-provider-bar" style="width: <?php echo esc_attr($percentage); ?>%"></div>
                                </div>
                                <span class="rnx-provider-count"><?php echo esc_html($p->count); ?></span>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </div>

        </div>
    </div>
    <?php
}
