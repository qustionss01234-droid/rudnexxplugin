<?php
if (!defined('ABSPATH')) {
    exit;
}

// Hook into Admin Init to intercept save and activate license
add_action('admin_init', 'rudnexx_check_license_activation');

function rudnexx_check_license_activation() {
    if (!isset($_POST['rudnexx_license_key'])) {
        return; // Not saving settings
    }

    $license_key = sanitize_text_field($_POST['rudnexx_license_key']);
    if (empty($license_key)) return;

    // Send Activation Request to Next.js API
    $response = wp_remote_post(RUDNEXX_API_URL . '/license/activate', [
        'body' => json_encode([
            'licenseKey' => $license_key,
            'domain' => $_SERVER['SERVER_NAME']
        ]),
        'headers' => ['Content-Type' => 'application/json']
    ]);

    if (is_wp_error($response)) {
        add_settings_error('rudnexx_messages', 'rudnexx_message', 'API Connection Failed', 'error');
        return;
    }

    $body = json_decode(wp_remote_retrieve_body($response), true);

    if (isset($body['status']) && $body['status'] === 'valid') {
        update_option('rudnexx_license_status', 'Active');
        if (isset($body['plan'])) {
            update_option('rudnexx_license_plan', $body['plan']);
        }
        add_settings_error('rudnexx_messages', 'rudnexx_message', 'License Activated Successfully!', 'success');
    } else {
        update_option('rudnexx_license_status', 'Invalid');
        update_option('rudnexx_license_plan', 'free');
        $error_msg = isset($body['error']) ? $body['error'] : 'Invalid License Key';
        add_settings_error('rudnexx_messages', 'rudnexx_message', $error_msg, 'error');
    }
}
