<?php
/**
 * Plugin Name: Rudnexx
 * Plugin URI: https://rudnex.in
 * Description: The ultimate AI Auto-Blogger. Bring Your Own Key, schedule posts, format like a human, and build SEO with automated internal linking.
 * Version: 1.0.0
 * Author: Rudnex
 * Author URI: https://rudnex.in
 * License: GPLv2 or later
 * Text Domain: rudnexx
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

// FORCE LOCAL ERROR LOGGING FOR DEBUGGING
ini_set('log_errors', 1);
ini_set('error_log', dirname(__FILE__) . '/rudnexx-debug.log');
error_reporting(E_ALL);

// Catch fatal errors immediately and log them
register_shutdown_function(function() {
    $error = error_get_last();
    if ($error && in_array($error['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR])) {
        error_log("RUDNEXX FATAL CRASH: " . print_r($error, true));
    }
});

// Define Plugin Constants
define('RUDNEXX_VERSION', '1.1.0');
define('RUDNEXX_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('RUDNEXX_PLUGIN_URL', plugin_dir_url(__FILE__));
define('RUDNEXX_API_URL', 'https://rudnex.in/api');

// Include Core Files
require_once RUDNEXX_PLUGIN_DIR . 'includes/admin-settings.php';
require_once RUDNEXX_PLUGIN_DIR . 'includes/api-client.php';
require_once RUDNEXX_PLUGIN_DIR . 'includes/api-endpoints.php';
require_once RUDNEXX_PLUGIN_DIR . 'includes/ai-generator.php';
require_once RUDNEXX_PLUGIN_DIR . 'includes/scheduler.php';
require_once RUDNEXX_PLUGIN_DIR . 'includes/gap-finder.php';
require_once RUDNEXX_PLUGIN_DIR . 'includes/analytics.php';

// Add custom cron intervals
add_filter('cron_schedules', 'rudnexx_add_custom_cron_intervals');
function rudnexx_add_custom_cron_intervals($schedules) {
    $schedules['five_minutes'] = [
        'interval' => 300,
        'display'  => __('Every 5 Minutes (Turbo)', 'rudnexx')
    ];
    return $schedules;
}

// Enqueue Frontend Styles & Scripts
add_action('wp_enqueue_scripts', 'rudnexx_enqueue_frontend_assets');
function rudnexx_enqueue_frontend_assets() {
    if (is_single() || is_page() || is_front_page()) {
        wp_enqueue_style('rudnexx-frontend', RUDNEXX_PLUGIN_URL . 'assets/rudnexx-frontend.css', [], RUDNEXX_VERSION);
        
        // Visitor Analytics Script
        wp_enqueue_script('rudnexx-analytics', RUDNEXX_PLUGIN_URL . 'assets/rudnexx-analytics.js', [], RUDNEXX_VERSION, true);

        wp_localize_script('rudnexx-analytics', 'rudnexx_vars', [
            'api_url'     => RUDNEXX_API_URL,
            'license_key' => get_option('rudnexx_license_key', ''),
        ]);
    }
}

// Activation Hook
register_activation_hook(__FILE__, 'rudnexx_activate_plugin');
function rudnexx_activate_plugin() {
    // Check if scheduled hook exists, if not create it with a delayed start
    if (!wp_next_scheduled('rudnexx_auto_blog_cron')) {
        $freq = get_option('rudnexx_schedule_frequency', 'hourly');
        $schedules = wp_get_schedules();
        $delay = isset($schedules[$freq]['interval']) ? $schedules[$freq]['interval'] : 3600;
        
        wp_schedule_event(time() + $delay, $freq, 'rudnexx_auto_blog_cron');
    }
}

// Deactivation Hook
register_deactivation_hook(__FILE__, 'rudnexx_deactivate_plugin');
function rudnexx_deactivate_plugin() {
    $timestamp = wp_next_scheduled('rudnexx_auto_blog_cron');
    if ($timestamp) {
        wp_unschedule_event($timestamp, 'rudnexx_auto_blog_cron');
    }
}

// Add Custom SEO Score Column
add_filter('manage_posts_columns', 'rudnexx_add_seo_score_column');
function rudnexx_add_seo_score_column($columns) {
    if (get_option('rudnexx_license_status') === 'Active') {
        $columns['rudnexx_seo_score'] = __('Rudnex SEO Score', 'rudnexx');
    }
    return $columns;
}

add_action('manage_posts_custom_column', 'rudnexx_show_seo_score_column', 10, 2);
function rudnexx_show_seo_score_column($column, $post_id) {
    if ($column === 'rudnexx_seo_score') {
        $score = get_post_meta($post_id, 'rudnexx_seo_score', true);
        if ($score) {
            $color = '#ef4444'; // Red for poor
            if ($score >= 80) $color = '#22c55e'; // Green for excellent
            elseif ($score >= 50) $color = '#eab308'; // Yellow for okay

            echo '<div style="display:inline-block; font-weight:bold; font-size:12px; color:#fff; background:' . $color . '; padding:4px 10px; border-radius:12px; box-shadow:0 2px 4px rgba(0,0,0,0.1);">' . esc_html($score) . '/100</div>';
        } else {
            echo '<span style="color:#a0aec0; font-size:12px;">N/A</span>';
        }
    }
}

// Fix Plugin Menu Logo Size
add_action('admin_head', 'rudnexx_fix_menu_logo');
function rudnexx_fix_menu_logo() {
    echo '<style>
        #toplevel_page_rudnexx-settings .wp-menu-image img {
            max-width: 20px !important;
            max-height: 20px !important;
            border-radius: 4px;
            object-fit: contain;
        }
    </style>';
}

